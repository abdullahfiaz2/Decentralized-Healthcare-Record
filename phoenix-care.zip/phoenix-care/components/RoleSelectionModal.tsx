// components/RoleSelectionModal.tsx
'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function RoleSelectionModal({ 
  onRoleSelected,
  userData
}: {
  onRoleSelected: (role: string) => void,
  userData: any
}) {
  const [selectedRole, setSelectedRole] = useState('');
  const router = useRouter();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedRole) {
      onRoleSelected(selectedRole);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white p-6 rounded-lg max-w-md w-full">
        <h2 className="text-xl font-bold mb-4">Select Your Role</h2>
        <p className="mb-4">Welcome, {userData.displayName || 'User'}! Please choose your role:</p>
        
        <form onSubmit={handleSubmit}>
          <div className="space-y-4 mb-6">
            <div className="flex items-center">
              <input
                type="radio"
                id="patient"
                name="role"
                value="patient"
                checked={selectedRole === 'patient'}
                onChange={() => setSelectedRole('patient')}
                className="mr-2"
                required
              />
              <label htmlFor="patient">Patient</label>
            </div>
            <div className="flex items-center">
              <input
                type="radio"
                id="doctor"
                name="role"
                value="doctor"
                checked={selectedRole === 'doctor'}
                onChange={() => setSelectedRole('doctor')}
                className="mr-2"
                required
              />
              <label htmlFor="doctor">Doctor</label>
            </div>
          </div>
          
          <button
            type="submit"
            className="w-full bg-green-600 text-white py-2 px-4 rounded"
            disabled={!selectedRole}
          >
            Continue
          </button>
        </form>
      </div>
    </div>
  );
}