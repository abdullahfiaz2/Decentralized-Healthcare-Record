// 'use client';
// import DashboardSidebar from '@/components/Dashboard/Sidebar';

// const DashboardLayout = ({ children }: { children: React.ReactNode }) => {
//     return (
//         <>
//             <div className="container-fluid" style={{ marginTop: '160px', marginBottom: '200px' }}>
//                 <div className="row">
//                     <div className="col-md-5 col-lg-4 col-xl-3">
//                         <DashboardSidebar />
//                     </div>
//                     <div className="col-md-7 col-lg-8 col-xl-9">
//                         {children}
//                     </div>
//                 </div>
//             </div>
//         </>
//     )
// }

// export default DashboardLayout;