'use client';
import { useState } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import avatar from '@/public/images/avatar.jpg';
import { FaEye, FaCheck, FaTimes, FaBriefcaseMedical } from "react-icons/fa";
import moment from 'moment';
import { Button, Tag, Tabs } from 'antd';

export default function DashboardHome(){
    // Static data for demonstration
    const staticAppointments = [
        {
            id: 1,
            patient: {
                firstName: 'John',
                lastName: 'Doe',
                img: avatar,
                designation: 'Patient'
            },
            scheduleDate: new Date(),
            scheduleTime: '10:00 AM',
            status: 'pending',
            prescriptionStatus: 'notIssued'
        },
        {
            id: 2,
            patient: {
                firstName: 'Jane',
                lastName: 'Smith',
                img: avatar,
                designation: 'Patient'
            },
            scheduleDate: new Date(),
            scheduleTime: '02:30 PM',
            status: 'accepted',
            prescriptionStatus: 'issued',
            prescription: [{ id: 101 }]
        }
    ];

    const [sortBy, setSortBy] = useState("upcoming");
    const [data] = useState(staticAppointments);

    const handleOnselect = (value) => {
        setSortBy(value == 1 ? 'upcoming' : value == 2 ? 'today' : sortBy);
    };

    // Mock function for UI demonstration
    const updatedApppointmentStatus = (data, type) => {
        console.log(`Would update appointment ${data.id} to status: ${type}`);
    };

    const upcomingColumns = [
        {
            title: 'Patient Name',
            key: '1',
            width: 100,
            render: function (data) {
                const fullName = `${data?.patient?.firstName ?? ''} ${data?.patient?.lastName ?? ''}`;
                const patientName = fullName.trim() || "Un Patient";
                const imgdata = data?.patient?.img ? data?.patient?.img : avatar;
                return (
                    <div className="table-avatar">
                        <div className="avatar avatar-sm mr-2 d-flex gap-2">
                            <Image 
                                className="avatar-img rounded-circle" 
                                src={imgdata} 
                                alt="Patient" 
                                width={40} 
                                height={40}
                            />
                            <div>
                                <p className='p-0 m-0 text-nowrap'>
                                    {patientName}
                                </p>
                                <p className='p-0 m-0'>{data?.patient?.designation}</p>
                            </div>
                        </div>
                    </div>
                );
            }
        },
        {
            title: 'App Date',
            key: '2',
            width: 100,
            render: function (data) {
                return (
                    <div>
                        {moment(data?.scheduleDate).format("LL")} 
                        <span className="d-block text-info">{data?.scheduleTime}</span>
                    </div>
                );
            }
        },
        {
            title: 'Status',
            key: '4',
            width: 100,
            render: function (data) {
                return (
                    <Tag color="#87d068" className='text-uppercase'>{data?.status}</Tag>
                );
            }
        },
        {
            title: 'Action',
            key: '5',
            width: 100,
            render: function (data) {
                return (
                    <div className='d-flex gap-2'>
                        {data.prescriptionStatus === 'notIssued' ? (
                            <Link href={`/dashboard/appointment/treatment/${data?.id}`}>
                                <Button type="primary" icon={<FaBriefcaseMedical />} size="small">Treatment</Button>
                            </Link>
                        ) : (
                            <Link href={`/dashboard/prescription/${data?.prescription?.[0]?.id}`}>
                                <Button type="primary" shape="circle" icon={<FaEye />} size="small" />
                            </Link>
                        )}
                        {data?.status === 'pending' && (
                            <>
                                <Button 
                                    type="primary" 
                                    icon={<FaCheck />} 
                                    size="small" 
                                    onClick={() => updatedApppointmentStatus(data, 'accept')}
                                >
                                    Accept
                                </Button>
                                <Button 
                                    type='primary' 
                                    icon={<FaTimes />} 
                                    size='small' 
                                    danger 
                                    onClick={() => updatedApppointmentStatus(data, 'cancel')}
                                >
                                    Cancel
                                </Button>
                            </>
                        )}
                    </div>
                );
            }
        },
    ];

    const items = [
        {
            key: '1',
            label: 'upcoming',
            children: (
                <div className="ant-table-wrapper">
                    <div className="ant-table">
                        <div className="ant-table-container">
                            <div className="ant-table-content">
                                <table style={{ width: '100%' }}>
                                    <thead className="ant-table-thead">
                                        <tr>
                                            {upcomingColumns.map(column => (
                                                <th key={column.key} style={{ width: column.width }}>
                                                    {column.title}
                                                </th>
                                            ))}
                                        </tr>
                                    </thead>
                                    <tbody className="ant-table-tbody">
                                        {data.map((item, index) => (
                                            <tr key={index}>
                                                {upcomingColumns.map(column => (
                                                    <td key={column.key}>
                                                        {column.render(item)}
                                                    </td>
                                                ))}
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            ),
        },
        {
            key: '2',
            label: 'today',
            children: (
                <div className="ant-table-wrapper">
                    <div className="ant-table">
                        <div className="ant-table-container">
                            <div className="ant-table-content">
                                <table style={{ width: '100%' }}>
                                    <thead className="ant-table-thead">
                                        <tr>
                                            {upcomingColumns.map(column => (
                                                <th key={column.key} style={{ width: column.width }}>
                                                    {column.title}
                                                </th>
                                            ))}
                                        </tr>
                                    </thead>
                                    <tbody className="ant-table-tbody">
                                        {data.map((item, index) => (
                                            <tr key={index}>
                                                {upcomingColumns.map(column => (
                                                    <td key={column.key}>
                                                        {column.render(item)}
                                                    </td>
                                                ))}
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            ),
        },
    ];

    return (
        <div className="p-4">
            <Tabs defaultActiveKey="1" items={items} onChange={handleOnselect} />
        </div>
    );
};

// export default DashboardPage;