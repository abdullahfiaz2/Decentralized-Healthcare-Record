'use client';
import { useState } from 'react';
import { Card, Statistic, Table, Tag, Progress, Avatar } from 'antd';
import DashboardSidebar from '@/components/Dashboard/Sidebar';
import { 
  FaCalendarAlt, 
  FaUserInjured, 
  FaMoneyBillWave,
  FaChartLine,
  FaClock,
  FaStethoscope
} from 'react-icons/fa';
import { FiCalendar, FiUsers, FiDollarSign } from 'react-icons/fi';
import moment from 'moment';

const DoctorDashboard = () => {
  // Mock data
  const stats = {
    totalAppointments: 42,
    todayAppointments: 5,
    totalPatients: 28,
    monthlyEarnings: 12500
  };

  const recentAppointments = [
    {
      id: '1',
      patient: {
        name: 'John Doe',
        avatar: '/patient1.jpg',
        age: 35
      },
      date: '2023-12-15',
      time: '10:00 AM',
      status: 'confirmed',
      type: 'Follow-up'
    },
    {
      id: '2',
      patient: {
        name: 'Sarah Smith',
        avatar: '/patient2.jpg',
        age: 42
      },
      date: '2023-12-15',
      time: '11:30 AM',
      status: 'confirmed',
      type: 'Consultation'
    },
    {
      id: '3',
      patient: {
        name: 'Michael Johnson',
        avatar: '/patient3.jpg',
        age: 28
      },
      date: '2023-12-15',
      time: '02:00 PM',
      status: 'pending',
      type: 'New Patient'
    }
  ];

  const upcomingSchedule = [
    {
      id: '1',
      date: '2023-12-16',
      time: '09:00 AM',
      patient: 'Robert Brown',
      purpose: 'Annual Checkup'
    },
    {
      id: '2',
      date: '2023-12-16',
      time: '11:00 AM',
      patient: 'Emily Davis',
      purpose: 'Vaccination'
    },
    {
      id: '3',
      date: '2023-12-17',
      time: '10:30 AM',
      patient: 'James Wilson',
      purpose: 'Follow-up'
    }
  ];

  const columns = [
    {
      title: 'Patient',
      dataIndex: 'patient',
      key: 'patient',
      render: (patient: any) => (
        <div className="flex items-center gap-3">
          <Avatar src={patient.avatar} />
          <div>
            <div className="font-medium">{patient.name}</div>
            <div className="text-gray-500 text-sm">Age: {patient.age}</div>
          </div>
        </div>
      ),
    },
    {
      title: 'Date & Time',
      dataIndex: 'date',
      key: 'date',
      render: (date: string, record: any) => (
        <div>
          <div>{moment(date).format('MMM Do, YYYY')}</div>
          <div className="text-gray-500">{record.time}</div>
        </div>
      ),
    },
    {
      title: 'Type',
      dataIndex: 'type',
      key: 'type',
    },
    {
      title: 'Status',
      dataIndex: 'status',
      key: 'status',
      render: (status: string) => (
        <Tag color={status === 'confirmed' ? 'green' : 'orange'}>
          {status.toUpperCase()}
        </Tag>
      ),
    },
  ];

  return (
    <div className="flex min-h-screen bg-gray-50">
      {/* Main Content Area */}
      <div className="sm:ml-64 ml-2 flex-1 p-8">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-2xl font-bold text-gray-800 mb-6">Doctor Dashboard</h1>
          
          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card className="shadow-sm hover:shadow-md transition-shadow">
              <Statistic
                title="Total Appointments"
                value={stats.totalAppointments}
                prefix={<FiCalendar className="text-blue-500" />}
                valueStyle={{ color: '#3f8600' }}
              />
              <Progress percent={75} showInfo={false} strokeColor="#52c41a" />
              <div className="text-sm text-gray-500 mt-2">+12% from last month</div>
            </Card>
            
            <Card className="shadow-sm hover:shadow-md transition-shadow">
              <Statistic
                title="Today's Appointments"
                value={stats.todayAppointments}
                prefix={<FaUserInjured className="text-purple-500" />}
                valueStyle={{ color: '#722ed1' }}
              />
              <div className="flex items-center gap-2 mt-2">
                <Tag color="green">5 Confirmed</Tag>
                <Tag color="orange">2 Pending</Tag>
              </div>
            </Card>
            
            <Card className="shadow-sm hover:shadow-md transition-shadow">
              <Statistic
                title="Total Patients"
                value={stats.totalPatients}
                prefix={<FiUsers className="text-green-500" />}
                valueStyle={{ color: '#13c2c2' }}
              />
              <div className="text-sm text-gray-500 mt-2">8 New this month</div>
            </Card>
            
            <Card className="shadow-sm hover:shadow-md transition-shadow">
              <Statistic
                title="Monthly Earnings"
                value={stats.monthlyEarnings}
                prefix={<FiDollarSign className="text-red-500" />}
                valueStyle={{ color: '#cf1322' }}
                suffix="$"
              />
              <Progress percent={60} showInfo={false} strokeColor="#ff4d4f" />
              <div className="text-sm text-gray-500 mt-2">Target: $20,000</div>
            </Card>
          </div>
          
          {/* Recent Appointments */}
          <Card 
            title={
              <div className="flex items-center gap-2">
                <FaClock className="text-blue-500" />
                <span>Today's Appointments</span>
              </div>
            }
            className="shadow-sm hover:shadow-md transition-shadow mb-8"
          >
            <Table
              columns={columns}
              dataSource={recentAppointments}
              pagination={false}
              rowKey="id"
            />
          </Card>
          
          <div className="grid grid-cols-1 mt-8 lg:grid-cols-2 gap-6">
            {/* Upcoming Schedule */}
            <Card 
              title={
                <div className="flex items-center gap-2">
                  <FaCalendarAlt className="text-green-500" />
                  <span>Upcoming Schedule</span>
                </div>
              }
              className="shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="space-y-4">
                {upcomingSchedule.map(appointment => (
                  <div key={appointment.id} className="flex items-start gap-4 p-3 hover:bg-gray-50 rounded-lg">
                    <div className="bg-blue-100 p-2 rounded-lg">
                      <FaStethoscope className="text-blue-600" />
                    </div>
                    <div className="flex-1">
                      <div className="font-medium">{appointment.patient}</div>
                      <div className="text-gray-600 text-sm">{appointment.purpose}</div>
                    </div>
                    <div className="text-right">
                      <div className="font-medium">{moment(appointment.date).format('MMM Do')}</div>
                      <div className="text-gray-500 text-sm">{appointment.time}</div>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
            
            {/* Quick Stats */}
            <Card 
              title={
                <div className="flex items-center gap-2">
                  <FaChartLine className="text-purple-500" />
                  <span>Practice Statistics</span>
                </div>
              }
              className="shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="space-y-6">
                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-gray-600">Appointment Types</span>
                    <span className="font-medium">100%</span>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Progress 
                        percent={45} 
                        strokeColor="#52c41a" 
                        showInfo={false} 
                        className="flex-1"
                      />
                      <span className="text-sm text-gray-500">Consultations (45%)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Progress 
                        percent={30} 
                        strokeColor="#1890ff" 
                        showInfo={false} 
                        className="flex-1"
                      />
                      <span className="text-sm text-gray-500">Follow-ups (30%)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Progress 
                        percent={15} 
                        strokeColor="#722ed1" 
                        showInfo={false} 
                        className="flex-1"
                      />
                      <span className="text-sm text-gray-500">Checkups (15%)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Progress 
                        percent={10} 
                        strokeColor="#faad14" 
                        showInfo={false} 
                        className="flex-1"
                      />
                      <span className="text-sm text-gray-500">Others (10%)</span>
                    </div>
                  </div>
                </div>
                
                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-gray-600">Patient Satisfaction</span>
                    <span className="font-medium">92%</span>
                  </div>
                  <Progress percent={92} strokeColor="#13c2c2" />
                </div>
                
                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-gray-600">Monthly Revenue Progress</span>
                    <span className="font-medium">$12,500/$20,000</span>
                  </div>
                  <Progress percent={62.5} strokeColor="#ff4d4f" />
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DoctorDashboard;