'use client';
import { Card, List, Avatar } from 'antd';
import DashboardSidebar from '@/components/Dashboard/Sidebar';
import { FaCalendarAlt } from 'react-icons/fa';
import moment from 'moment';

const PatientDashboard = () => {
  // Dummy upcoming appointments
  const upcomingAppointments = [
    {
      id: '1',
      doctor: 'Dr. Sarah Khan',
      date: '2025-05-20',
      time: '10:30 AM',
      avatar: '/doctor1.jpg',
      purpose: 'General Consultation',
    },
    {
      id: '2',
      doctor: 'Dr. Imran Ali',
      date: '2025-05-22',
      time: '02:00 PM',
      avatar: '/doctor2.jpg',
      purpose: 'Follow-up',
    },
  ];

  return (
    <div className="flex min-h-screen bg-gray-50">
      {/* Sidebar */}
      {/* <div className="w-64 fixed h-full bg-white shadow">
        <DashboardSidebar activeTab="dashboard" />
      </div> */}

      {/* Main Content */}
      <div className="sm:ml-64 ml-2  flex-1 p-6">
        <h1 className="text-2xl font-bold mb-6 text-gray-800">Patient Dashboard</h1>

        <Card
          title={
            <div className="flex items-center gap-2 text-lg font-semibold">
              <FaCalendarAlt className="text-blue-500" />
              Upcoming Appointments
            </div>
          }
          className="shadow-sm"
        >
          <List
            itemLayout="horizontal"
            dataSource={upcomingAppointments}
            renderItem={(item) => (
              <List.Item>
                <List.Item.Meta
                  avatar={<Avatar src={item.avatar} />}
                  title={<span>{item.doctor}</span>}
                  description={
                    <>
                      <div>{item.purpose}</div>
                      <div className="text-sm text-gray-500">
                        {moment(item.date).format('MMM Do, YYYY')} at {item.time}
                      </div>
                    </>
                  }
                />
              </List.Item>
            )}
          />
        </Card>
      </div>
    </div>
  );
};

export default PatientDashboard;
