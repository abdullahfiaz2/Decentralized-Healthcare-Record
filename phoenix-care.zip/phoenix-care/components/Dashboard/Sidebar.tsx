'use client';
import Image from 'next/image';
import Link from 'next/link';
import { useState, useEffect } from 'react';
import avatar from '@/public/images/avatar.jpg';
import {
  FaTable, FaCalendarDay, FaUserInjured, FaHourglassStart,
  FaRegStar, FaUserCog, FaBlog, FaSignOutAlt, FaLock, 
  FaHouseUser, FaBars, FaTimes
} from "react-icons/fa";
import { useAuth } from '@/app/Context/AuthContext';

const DashboardSidebar = () => {
  const { user, role, logout } = useAuth();
  const [isOpen, setIsOpen] = useState(false);
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768);
    };

    // Set initial state
    handleResize();

    // Add event listener
    window.addEventListener('resize', handleResize);

    // Clean up
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const toggleSidebar = () => {
    setIsOpen(!isOpen);
  };
    const handleLogout = async () => {
    await logout();

  };

  return (
    <>
      {/* Mobile Navbar Button */}
      {isMobile && (
        <button 
          onClick={toggleSidebar}
          className="fixed top-4 left-4 z-50 p-2 bg-white rounded-md shadow-md"
        >
          {isOpen ? <FaTimes size={24} /> : <FaBars size={24} />}
        </button>
      )}

      {/* Sidebar */}
      <div 
        className={`profile-sidebar px-4 rounded ${isMobile ? 
          `fixed top-0 left-0 h-full w-64 bg-white z-40 transform transition-transform duration-300 ease-in-out shadow-lg ${isOpen ? 'translate-x-0' : '-translate-x-full'}` : 
          ''}`}
      >
        <div className="p-2 text-center border-b border-gray-300">
          <div className="profile-info text-center">
            <Link href="/">
              <Image
                src={user?.photoURL || avatar}
                alt="avatar"
                width={80}
                height={80}
                className="rounded-full mx-auto"
              />
            </Link>
            <div className="profile-details mt-2">
              <h5 className='mb-1'>{user?.displayName || 'User'}</h5>
              {role !== 'doctor' && (
                <>
                  <p className="text-sm m-0">24 Jul 1983, 38 Years</p>
                  <p className="text-sm m-0">New York, USA</p>
                  <p className="text-sm m-0">{user?.email}</p>
                </>
              )}
            </div>
          </div>
        </div>

        <nav className="dashboard-menu mt-2">
          <ul className="space-y-4">
            <li>
              <Link href="/dashboard" className="flex items-center px-3 py-2 gap-3">
                <FaTable size={20} /> <span>Dashboard</span>
              </Link>
            </li>

            {role === 'patient' ? (
              <>
                <li>
                  <Link href="/dashboard/Booking" className="flex items-center px-3 py-2 gap-3">
                    <FaUserInjured size={20} /> <span>Create Booking</span>
                  </Link>
                </li>
                <li>
                  <Link href="/dashboard/MyBookings" className="flex items-center px-3 py-2 gap-3">
                    <FaHouseUser size={20} /> <span>My Bookings</span>
                  </Link>
                </li>
                <li>
                  <Link href="/dashboard/user-profile-setting" className="flex items-center px-3 py-2 gap-3">
                    <FaUserCog size={20} /> <span>Profile Settings</span>
                  </Link>
                </li>
                <li>
                  <Link href="/dashboard/ChangePassword" className="flex items-center px-3 py-2 gap-3">
                    <FaLock size={20} /> <span>Change Password</span>
                  </Link>
                </li>
                <li>
                  <Link href="/dashboard/Add-Report" className="flex items-center px-3 py-2 gap-3">
                    <FaUserCog size={20} /> <span>Add Report</span>
                  </Link>
                </li>
                <li>
                  <button 
                   onClick={handleLogout}
                    className="flex items-center px-3 py-2 gap-3 w-full text-left"
                  >
                    <FaSignOutAlt size={20} /> <span>Logout</span>
                  </button>
                </li>
              </>
            ) : (
              <>
                <li>
                  <Link href="/dashboard/Appointments" className="flex items-center px-3 py-2 gap-3">
                    <FaCalendarDay size={20} /> <span>Appointments</span>
                  </Link>
                </li>
                <li>
                  <Link href="/dashboard/MyPatients" className="flex items-center px-3 py-2 gap-3">
                    <FaUserInjured size={20} /> <span>My Patients</span>
                  </Link>
                </li>
                <li>
                  <Link href="/dashboard/ScheduleTime" className="flex items-center px-3 py-2 gap-3">
                    <FaCalendarDay size={20} /> <span>Schedule Timings</span>
                  </Link>
                </li>
                <li>
                  <Link href="/dashboard/doctor-profile-setting" className="flex items-center px-3 py-2 gap-3">
                    <FaUserCog size={20} /> <span>Profile Settings</span>
                  </Link>
                </li>
                      <li>
                  <Link href="/dashboard/Add-Report" className="flex items-center px-3 py-2 gap-3">
                    <FaUserCog size={20} /> <span>Add Report</span>
                  </Link>
                </li>
                <li>
                  <button 
                  onClick={handleLogout}
                   className="flex items-center px-3 py-2 gap-3 w-full text-left"
                  >
                    <FaSignOutAlt size={20} /> <span>Logout</span>
                  </button>
                </li>
              </>
            )}
          </ul>
        </nav>
      </div>

      {/* Overlay for mobile when sidebar is open */}
      {isMobile && isOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-30"
          onClick={toggleSidebar}
        />
      )}
    </>
  );
};

export default DashboardSidebar;