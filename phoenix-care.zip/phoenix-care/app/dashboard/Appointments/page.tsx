'use client';
import { FaEye, FaCheck, FaTimes, FaClock, FaEnvelope, FaLocationArrow, FaPhoneAlt, FaBriefcaseMedical } from "react-icons/fa";
import { Button, Empty, message, Tag, Tooltip } from 'antd';
import moment from 'moment';
import Image from 'next/image';
import Link from 'next/link';
import DashboardSidebar from '@/components/Dashboard/Sidebar';
import avatar from '@/public/images/avatar.jpg';

const AppointmentsPage = () => {
  // Mock data for static frontend
  const appointments = [
    {
      id: '1',
      patient: {
        firstName: 'John',
        lastName: 'Doe',
        img: avatar,
        address: '123 Main St, New York',
        email: 'john@example.com',
        phone: '123-456-7890'
      },
      trackingId: 'TRK12345',
      appointmentTime: new Date(),
      status: 'pending',
      patientType: 'new',
      isFollowUp: false,
      paymentStatus: 'paid',
      prescriptionStatus: 'notIssued',
      prescription: [{ id: '1' }]
    },
    {
      id: '2',
      patient: {
        firstName: 'Jane',
        lastName: 'Smith',
        img: avatar,
        address: '456 Park Ave, Boston',
        email: 'jane@example.com',
        phone: '987-654-3210'
      },
      trackingId: 'TRK67890',
      appointmentTime: new Date(),
      status: 'scheduled',
      patientType: 'returning',
      isFollowUp: true,
      paymentStatus: 'paid',
      prescriptionStatus: 'issued',
      prescription: [{ id: '2' }]
    }
  ];

  const handleStatusUpdate = (id: string, type: string) => {
    console.log(`Updating appointment ${id} to ${type}`);
    message.success(`Appointment status updated to ${type}`);
  };

  const getPatientName = (patient: any) => {
    return `${patient?.firstName || ''} ${patient?.lastName || ''}`.trim() || "Private Patient";
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    message.success('Copied to clipboard!');
  };

  return (
    <div className="flex min-h-screen bg-gray-50">
      {/* Fixed Sidebar */}
         <div className="sm:w-64 sm:fixed h-full bg-white shadow z-10 overflow-auto scrollbar-hide">
        <DashboardSidebar />
      </div>
      
      {/* Main Content Area */}
      <div className="sm:ml-64 ml-2 flex-1 p-8">
        <h1 className="text-2xl font-bold text-gray-800 mb-6">Appointments</h1>
        
        {appointments.length === 0 ? (
          <Empty description="No appointments found" />
        ) : (
          <div className="space-y-4">
            {appointments.map((appointment) => (
              <div 
                key={appointment.id}
                className="bg-white rounded-lg shadow p-6 hover:shadow-md transition-shadow"
              >
                <div className="flex flex-col md:flex-row justify-between gap-6">
                  {/* Patient Info Section */}
                  <div className="flex flex-col md:flex-row gap-6 flex-1">
                    {/* Patient Avatar */}
                    <div className="flex-shrink-0">
                      <Link href="#" className="block">
                        <Image
                          src={appointment.patient?.img || avatar}
                          alt="Patient"
                          width={120}
                          height={120}
                          className="rounded-full border-4 border-gray-100 hover:border-blue-200 transition-all"
                        />
                      </Link>
                    </div>
                    
                    {/* Patient Details */}
                    <div className="flex-1">
                      <h2 className="text-xl font-semibold text-blue-800 hover:text-blue-600 transition-colors">
                        {getPatientName(appointment.patient)}
                      </h2>
                      
                      <Tooltip title="Click to copy tracking ID">
                        <div className="mt-2">
                          <span className="font-medium">Tracking: </span>
                          <Tag 
                            color="green" 
                            className="cursor-pointer hover:bg-green-100"
                            onClick={() => copyToClipboard(appointment.trackingId)}
                          >
                            {appointment.trackingId}
                          </Tag>
                        </div>
                      </Tooltip>
                      
                      <div className="mt-3 space-y-2 text-gray-600">
                        <p className="flex items-center gap-2">
                          <FaClock className="text-blue-500" />
                          {moment(appointment.appointmentTime).format("MMM Do YYYY, h:mm a")}
                        </p>
                        {appointment.patient.address && (
                          <p className="flex items-center gap-2">
                            <FaLocationArrow className="text-blue-500" />
                            {appointment.patient.address}
                          </p>
                        )}
                        {appointment.patient.email && (
                          <p className="flex items-center gap-2">
                            <FaEnvelope className="text-blue-500" />
                            {appointment.patient.email}
                          </p>
                        )}
                        {appointment.patient.phone && (
                          <p className="flex items-center gap-2">
                            <FaPhoneAlt className="text-blue-500" />
                            {appointment.patient.phone}
                          </p>
                        )}
                      </div>
                    </div>
                    
                    {/* Appointment Status */}
                    <div className="border-l-2 border-gray-200 pl-4 py-2">
                      <div className="space-y-2">
                        <p className="flex justify-between">
                          <span className="font-medium">Status:</span>
                          <Tag color="orange" className="uppercase">{appointment.status}</Tag>
                        </p>
                        <p className="flex justify-between">
                          <span className="font-medium">Patient Type:</span>
                          <Tag color="blue" className="uppercase">{appointment.patientType}</Tag>
                        </p>
                        <p className="flex justify-between">
                          <span className="font-medium">Follow Up:</span>
                          <Tag color={appointment.isFollowUp ? "orange" : "gray"} className="uppercase">
                            {appointment.isFollowUp ? "Yes" : "No"}
                          </Tag>
                        </p>
                        <p className="flex justify-between">
                          <span className="font-medium">Payment:</span>
                          <Tag color="green" className="uppercase">{appointment.paymentStatus}</Tag>
                        </p>
                        <p className="flex justify-between">
                          <span className="font-medium">Prescription:</span>
                          <Tag color="blue" className="uppercase">{appointment.prescriptionStatus}</Tag>
                        </p>
                      </div>
                    </div>
                  </div>
                  
                  {/* Action Buttons */}
                  <div className="flex flex-col md:flex-row gap-2 self-center">
                    <Link href={`/dashboard/appointments/${appointment.id}`}>
                      <Button type="primary" icon={<FaEye />}>View</Button>
                    </Link>
                    
                    {appointment.prescriptionStatus === 'notIssued' ? (
                      <Link href={`/dashboard/appointment/treatment/${appointment.id}`}>
                        <Button type="primary" icon={<FaBriefcaseMedical />}>Treatment</Button>
                      </Link>
                    ) : (
                      <Link href={`/dashboard/prescription/${appointment.prescription[0]?.id}`}>
                        <Button type="primary" icon={<FaEye />}>Prescription</Button>
                      </Link>
                    )}
                    
                    {appointment.isFollowUp && (
                      <Link href={`/dashboard/appointment/treatment/edit/${appointment.prescription[0]?.id}`}>
                        <Button type="primary" icon={<FaBriefcaseMedical />}>Follow Up</Button>
                      </Link>
                    )}
                    
                    {appointment.status === 'pending' && (
                      <>
                        <Button 
                          type="primary" 
                          icon={<FaCheck />}
                          onClick={() => handleStatusUpdate(appointment.id, 'scheduled')}
                        >
                          Accept
                        </Button>
                        <Button 
                          type="primary" 
                          icon={<FaTimes />} 
                          danger
                          onClick={() => handleStatusUpdate(appointment.id, 'cancel')}
                        >
                          Cancel
                        </Button>
                      </>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default AppointmentsPage;