'use client';
import Image from 'next/image';
import Link from 'next/link';
import { FaClock, FaEnvelope, FaLocationArrow, FaPhoneAlt } from "react-icons/fa";
import { Empty } from 'antd';
import moment from 'moment';
import DashboardSidebar from '@/components/Dashboard/Sidebar';
import avatar from '@/public/images/avatar.jpg';

const MyPatientsPage = () => {
  // Static mock data
  const patients = [
    {
      id: '1',
      firstName: 'John',
      lastName: 'Doe',
      img: avatar,
      address: '123 Main St, New York',
      email: 'john@example.com',
      mobile: '123-456-7890',
      appointmentTime: new Date()
    },
    {
      id: '2',
      firstName: 'Jane',
      lastName: 'Smith',
      img: avatar,
      address: '456 Park Ave, Boston',
      email: 'jane@example.com',
      mobile: '987-654-3210',
      appointmentTime: new Date()
    },
    {
      id: '3',
      firstName: 'Robert',
      lastName: 'Johnson',
      img: avatar,
      address: '789 Oak St, Chicago',
      email: 'robert@example.com',
      mobile: '555-123-4567',
      appointmentTime: new Date()
    }
  ];

  const getPatientName = (patient: any) => {
    return `${patient?.firstName || ''} ${patient?.lastName || ''}`.trim() || "Private Patient";
  };

  return (
    <div className="flex min-h-screen bg-gray-50">
      {/* Fixed Sidebar */}
    <div className="sm:w-64 sm:fixed h-full bg-white shadow z-10 overflow-auto scrollbar-hide">
        <DashboardSidebar />
      </div>
      {/* Main Content Area */}
      <div className="sm:ml-64 ml-2 flex-1 p-8">
        <h1 className="text-2xl font-bold text-gray-800 mb-6">My Patients</h1>
        
        {patients.length === 0 ? (
          <Empty description="No patients found" />
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {patients.map((patient) => (
              <div 
                key={patient.id}
                className="bg-white rounded-lg shadow p-6 hover:shadow-md transition-shadow text-center"
              >
                <Link href="#" className="block my-3">
                  <Image
                    src={patient.img || avatar}
                    alt="Patient"
                    width={120}
                    height={120}
                    className="rounded-full border-4 border-gray-100 hover:border-blue-200 transition-all mx-auto"
                  />
                </Link>
                
                <div className="patients-info mt-4">
                  <h2 className="text-xl font-semibold text-blue-800 hover:text-blue-600 transition-colors">
                    {getPatientName(patient)}
                  </h2>
                  
                  <div className="info mt-4 space-y-2 text-gray-600">
                    <p className="flex items-center justify-center gap-2">
                      <FaClock className="text-blue-500" />
                      {moment(patient.appointmentTime).format("MMM Do YYYY")}
                    </p>
                    <p className="flex items-center justify-center gap-2">
                      <FaLocationArrow className="text-blue-500" />
                      {patient.address}
                    </p>
                    <p className="flex items-center justify-center gap-2">
                      <FaEnvelope className="text-blue-500" />
                      {patient.email}
                    </p>
                    <p className="flex items-center justify-center gap-2">
                      <FaPhoneAlt className="text-blue-500" />
                      {patient.mobile}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default MyPatientsPage;