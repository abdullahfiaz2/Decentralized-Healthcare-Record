'use client';
import { useState } from 'react';
import DashboardSidebar from '@/components/Dashboard/Sidebar';
import { Button, Card, DatePicker, Select, TimePicker, message } from 'antd';
import { FaCalendarAlt, FaClock, FaSearch, FaUserMd } from 'react-icons/fa';
import moment from 'moment';
const BookingPage = () => {
  const [selectedDate, setSelectedDate] = useState<string | null>(null);
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  const [selectedDoctor, setSelectedDoctor] = useState<string | null>(null);
  const [bookingStep, setBookingStep] = useState<number>(1);

  // Mock data
  const doctors = [
    { id: '1', name: 'Dr. Sarah Johnson', specialty: 'Cardiologist' },
    { id: '2', name: 'Dr. Michael Chen', specialty: 'Neurologist' },
    { id: '3', name: 'Dr. Emily Wilson', specialty: 'Pediatrician' },
  ];

  const availableTimes = [
    '09:00 AM', '10:00 AM', '11:00 AM', 
    '02:00 PM', '03:00 PM', '04:00 PM'
  ];

  const handleBookAppointment = () => {
    if (!selectedDoctor || !selectedDate || !selectedTime) {
      message.error('Please fill all fields');
      return;
    }
    message.success('Appointment booked successfully!');
    setBookingStep(1);
    setSelectedDate(null);
    setSelectedTime(null);
    setSelectedDoctor(null);
  };

  return (
    <div className="flex min-h-screen bg-gray-50">
      {/* Fixed Sidebar */}
       <div className="sm:w-64 sm:fixed h-full bg-white shadow z-10 overflow-auto scrollbar-hide">
        <DashboardSidebar />
      </div>
      
      {/* Main Content Area */}
      <div className="sm:ml-64 ml-2 flex-1 p-8">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-3xl font-bold text-gray-800 mb-6">Book an Appointment</h1>
          
          <Card className="shadow-lg">
            {/* Step 1: Select Doctor */}
            {bookingStep === 1 && (
              <div className="space-y-6">
                <div className="flex items-center gap-3 text-xl font-semibold text-blue-600">
                  <FaUserMd />
                  <h2>1. Choose Your Doctor</h2>
                </div>
                
                <Select
                  placeholder="Search for a doctor"
                  optionFilterProp="children"
                  showSearch
                  className="w-full"
                  suffixIcon={<FaSearch />}
                  onChange={(value) => setSelectedDoctor(value)}
                  options={doctors.map(doctor => ({
                    value: doctor.id,
                    label: (
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                          <FaUserMd className="text-blue-600" />
                        </div>
                        <div>
                          <div className="font-medium">{doctor.name}</div>
                          <div className="text-sm text-gray-500">{doctor.specialty}</div>
                        </div>
                      </div>
                    ),
                  }))}
                />
                
                {selectedDoctor && (
                  <div className="flex justify-end">
                    <Button 
                      type="primary" 
                      onClick={() => setBookingStep(2)}
                      className="bg-blue-600 hover:bg-blue-700"
                    >
                      Next: Select Date
                    </Button>
                  </div>
                )}
              </div>
            )}
            
            {/* Step 2: Select Date */}
            {bookingStep === 2 && (
              <div className="space-y-6">
                <div className="flex items-center gap-3 text-xl font-semibold text-blue-600">
                  <FaCalendarAlt />
                  <h2>2. Choose Appointment Date</h2>
                </div>
                
                <DatePicker
                  className="w-full"
                  disabledDate={(current) => {
                    return current && current < moment().startOf('day');
                  }}
                  onChange={(date, dateString) => setSelectedDate(Array.isArray(dateString) ? dateString[0] : dateString)}
                />
                
                <div className="flex justify-between">
                  <Button onClick={() => setBookingStep(1)}>Back</Button>
                  {selectedDate && (
                    <Button 
                      type="primary" 
                      onClick={() => setBookingStep(3)}
                      className="bg-blue-600 hover:bg-blue-700"
                    >
                      Next: Select Time
                    </Button>
                  )}
                </div>
              </div>
            )}
            
            {/* Step 3: Select Time */}
            {bookingStep === 3 && (
              <div className="space-y-6">
                <div className="flex items-center gap-3 text-xl font-semibold text-blue-600">
                  <FaClock />
                  <h2>3. Choose Appointment Time</h2>
                </div>
                
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {availableTimes.map(time => (
                    <Button
                      key={time}
                      type={selectedTime === time ? 'primary' : 'default'}
                      className={`h-14 ${selectedTime === time ? 'bg-blue-600' : 'hover:border-blue-300'}`}
                      onClick={() => setSelectedTime(time)}
                    >
                      {time}
                    </Button>
                  ))}
                </div>
                
                <div className="flex justify-between">
                  <Button onClick={() => setBookingStep(2)}>Back</Button>
                  {selectedTime && (
                    <Button 
                      type="primary" 
                      onClick={() => setBookingStep(4)}
                      className="bg-blue-600 hover:bg-blue-700"
                    >
                      Next: Confirm Booking
                    </Button>
                  )}
                </div>
              </div>
            )}
            
            {/* Step 4: Confirm Booking */}
            {bookingStep === 4 && (
              <div className="space-y-6">
                <h2 className="text-xl font-semibold text-blue-600">4. Confirm Your Appointment</h2>
                
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Doctor:</span>
                      <span className="font-medium">
                        {doctors.find(d => d.id === selectedDoctor)?.name}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Date:</span>
                      <span className="font-medium">{selectedDate}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Time:</span>
                      <span className="font-medium">{selectedTime}</span>
                    </div>
                  </div>
                </div>
                
                <div className="flex justify-between">
                  <Button onClick={() => setBookingStep(3)}>Back</Button>
                  <Button 
                    type="primary" 
                    onClick={handleBookAppointment}
                    className="bg-green-600 hover:bg-green-700"
                  >
                    Confirm Booking
                  </Button>
                </div>
              </div>
            )}
          </Card>
          
          {/* Doctor Info Card (example) */}
          {bookingStep === 1 && (
            <Card className="mt-6 shadow-md">
              <div className="flex items-start gap-4">
                <div className="w-20 h-20 rounded-full bg-blue-100 flex items-center justify-center">
                  <FaUserMd className="text-3xl text-blue-600" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold">Need help choosing?</h3>
                  <p className="text-gray-600 mt-2">
                    Our specialists are available to help you find the right doctor 
                    for your needs. Browse by specialty or use our search feature.
                  </p>
                </div>
              </div>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
};

export default BookingPage;