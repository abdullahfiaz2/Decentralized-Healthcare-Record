// app/dashboard/files/page.tsx
'use client';
import { useState, useRef, ChangeEvent } from 'react';
import { useAuth } from '@/app/Context/AuthContext';
import DashboardSidebar from '@/components/Dashboard/Sidebar';
import { FiUpload, FiFile, FiTrash2, FiDownload } from 'react-icons/fi';

interface UploadedFile {
  id: string;
  name: string;
  size: string;
  type: string;
  date: string;
}

export default function FileUploadPage() {
  const { user, role } = useAuth();
  const [files, setFiles] = useState<UploadedFile[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Sample initial files (replace with your actual files)
  const initialFiles: UploadedFile[] = [
    {
      id: '1',
      name: 'Medical_Report.pdf',
      size: '2.4 MB',
      type: 'pdf',
      date: '2023-05-15'
    },
    {
      id: '2',
      name: 'Prescription.jpg',
      size: '1.2 MB',
      type: 'image',
      date: '2023-06-20'
    },
    {
      id: '3',
      name: 'Lab_Results.xlsx',
      size: '3.1 MB',
      type: 'excel',
      date: '2023-07-10'
    }
  ];

  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>(initialFiles);

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const newFiles = Array.from(e.target.files).map(file => ({
        id: Math.random().toString(36).substring(2, 9),
        name: file.name,
        size: `${(file.size / (1024 * 1024)).toFixed(1)} MB`,
        type: file.type.split('/')[0] || 'file',
        date: new Date().toISOString().split('T')[0]
      }));
      setUploadedFiles(prev => [...newFiles, ...prev]);
    }
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files) {
      handleFileChange({
        target: { files: e.dataTransfer.files }
      } as unknown as ChangeEvent<HTMLInputElement>);
    }
  };

  const handleDelete = (id: string) => {
    setUploadedFiles(prev => prev.filter(file => file.id !== id));
  };

  const triggerFileInput = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Fixed Sidebar - Left Side */}
      <div className="sm:w-64 sm:fixed h-full bg-white shadow z-10 overflow-auto scrollbar-hide">
        <DashboardSidebar />
      </div>
      
      {/* Main Content - Right Side */}
      <div className="flex-1 sm:ml-64 ml-2 overflow-y-auto p-8">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-2xl font-bold text-gray-800 mb-6">File Management</h1>
          
          {/* File Upload Section */}
          <div 
            className={`border-2 border-dashed rounded-xl p-8 mb-8 text-center transition-all 
              ${isDragging ? 'border-blue-500 bg-blue-50' : 'border-gray-300'}`}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            onClick={triggerFileInput}
          >
            <div className="flex flex-col items-center justify-center space-y-3">
              <FiUpload className="text-4xl text-blue-500" />
              <h3 className="text-lg font-medium text-gray-700">
                {isDragging ? 'Drop files here' : 'Drag & drop files or click to browse'}
              </h3>
              <p className="text-sm text-gray-500">
                Supported formats: PDF, JPG, PNG, DOCX, XLSX (Max 10MB)
              </p>
              <button 
                type="button"
                className="mt-4 bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition"
              >
                Select Files
              </button>
            </div>
            <input 
              type="file" 
              ref={fileInputRef}
              onChange={handleFileChange}
              className="hidden"
              multiple
            />
          </div>
          
          {/* Uploaded Files List */}
          <div className="bg-white rounded-xl shadow overflow-hidden">
            <div className="p-4 border-b bg-gray-50">
              <h3 className="font-medium text-gray-700">Uploaded Files</h3>
            </div>
            
            {uploadedFiles.length === 0 ? (
              <div className="p-8 text-center text-gray-500">
                No files uploaded yet
              </div>
            ) : (
              <ul className="divide-y">
                {uploadedFiles.map((file) => (
                  <li key={file.id} className="p-4 hover:bg-gray-50 transition">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <div className={`p-3 rounded-lg ${
                          file.type === 'pdf' ? 'bg-red-100 text-red-500' :
                          file.type === 'image' ? 'bg-blue-100 text-blue-500' :
                          'bg-green-100 text-green-500'
                        }`}>
                          <FiFile className="text-xl" />
                        </div>
                        <div>
                          <p className="font-medium text-gray-800">{file.name}</p>
                          <p className="text-sm text-gray-500">
                            {file.size} • {file.type.toUpperCase()} • {file.date}
                          </p>
                        </div>
                      </div>
                      <div className="flex space-x-3">
                        <button 
                          className="text-blue-600 hover:text-blue-800 p-2"
                          title="Download"
                        >
                          <FiDownload />
                        </button>
                        <button 
                          className="text-red-600 hover:text-red-800 p-2"
                          title="Delete"
                          onClick={() => handleDelete(file.id)}
                        >
                          <FiTrash2 />
                        </button>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}