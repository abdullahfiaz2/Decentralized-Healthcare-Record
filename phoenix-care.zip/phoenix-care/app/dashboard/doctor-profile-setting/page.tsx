'use client';
import { useState } from 'react';
import moment from 'moment';
import { useForm } from 'react-hook-form';
import { Button, Select, DatePicker, message } from 'antd';
import Link from 'next/link';
import Image from 'next/image';
import avatar from '@/public/images/avatar.jpg';
import DashboardSidebar from '@/components/Dashboard/Sidebar';

// Static data for specialist options
const doctorSpecialistOptions: { value: string; label: string }[] = [
  { value: 'Cardiology', label: 'Cardiology' },
  { value: 'Neurology', label: 'Neurology' },
  { value: 'Pediatrics', label: 'Pediatrics' },
  { value: 'Dermatology', label: 'Dermatology' },
  { value: 'Orthopedics', label: 'Orthopedics' },
];

type FormData = {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  biography: string;
  clinicName: string;
  clinicAddress: string;
  address: string;
  city: string;
  state: string;
  country: string;
  postalCode: string;
  price: number;
  specialization: string;
  degree: string;
  college: string;
  completionYear: string;
  experienceHospitalName: string;
  expericenceStart: string;
  expericenceEnd: string;
  designation: string;
  award: string;
  awardYear: string;
  registration: string;
  year: string;
};

const DoctorProfileSetting = () => {
  const [selectedItems, setSelectedItems] = useState<string[]>([]);
  const { register, handleSubmit } = useForm<FormData>();
  const [selectValue, setSelectValue] = useState<Record<string, string>>({});
  const [date, setDate] = useState<string | null>(null);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [file, setFile] = useState<File | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Static data for demonstration
  const staticData = {
    id: '1',
    firstName: 'John',
    lastName: 'Doe',
    email: 'john.doe@example.com',
    phone: '1234567890',
    gender: 'male',
    dob: '1990-01-01',
    biography: 'Experienced doctor with 10 years of practice',
    clinicName: 'City Medical Center',
    clinicAddress: '123 Main Street',
    address: '456 Park Avenue',
    city: 'New York',
    state: 'NY',
    country: 'USA',
    postalCode: '10001',
    price: 100,
    services: 'Cardiology,Neurology',
    specialization: 'Cardiac Surgeon',
    degree: 'MD',
    college: 'Harvard Medical School',
    completionYear: '2010',
    experienceHospitalName: 'General Hospital',
    expericenceStart: '2010',
    expericenceEnd: '2020',
    designation: 'Senior Doctor',
    award: 'Best Doctor Award',
    awardYear: '2018',
    registration: 'Medical Board No.12345',
    year: '2010',
    img: avatar
  };

  const handleChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setSelectValue({ ...selectValue, [e.target.name]: e.target.value });
  };

    const onChange = (
      date: moment.Moment | null,
      dateString: string | string[]
    ) => {
      if (typeof dateString === "string") {
        setDate(moment(dateString).format());
      }
    };
  

  const onSubmit = (data: FormData) => {
    setIsLoading(true);
    console.log('Form submitted:', data);
    setTimeout(() => {
      setIsLoading(false);
      message.success('Profile updated successfully!');
    }, 1500);
  };

  return (
    <div className="flex min-h-screen bg-gray-50">
      {/* Sidebar - Fixed width */}
    <div className=" sm:w-64 sm:fixed h-full bg-white shadow z-10 overflow-auto scrollbar-hide">
        <DashboardSidebar />
      </div>
      {/* Main Content - Pushed right by sidebar width */}
      <div className="sm:ml-64 ml-2 flex-1 p-8">
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-2xl font-bold text-gray-800 mb-6">Update Your Information</h2>
          
          <form onSubmit={handleSubmit(onSubmit)}>
            {/* Avatar Section */}
            <div className="mb-8">
              <div className="flex items-center gap-4">
                <div className="relative">
                  <Image 
                    src={selectedImage || staticData.img} 
                    alt="Profile" 
                    width={100} 
                    height={100}
                    className="rounded-full border-2 border-gray-200"
                  />
                </div>
                <div>
                  <button 
                    type="button"
                    className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition"
                  >
                    Change Avatar
                  </button>
                  <p className="text-sm text-gray-500 mt-2">JPG, GIF or PNG. Max size of 2MB</p>
                </div>
              </div>
            </div>

            {/* Personal Information */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  First Name <span className="text-red-500">*</span>
                </label>
                <input 
                  defaultValue={staticData.firstName} 
                  {...register("firstName")} 
                  className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Last Name <span className="text-red-500">*</span>
                </label>
                <input 
                  defaultValue={staticData.lastName} 
                  {...register("lastName")} 
                  className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                <input 
                  defaultValue={staticData.email} 
                  className="w-full px-3 py-2 border border-gray-300 rounded bg-gray-100 cursor-not-allowed"
                  disabled
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Phone Number</label>
                <input 
                  defaultValue={staticData.phone} 
                  {...register("phone")} 
                  className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Gender</label>
                <select 
                  className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  onChange={handleChange} 
                  name='gender'
                  defaultValue={staticData.gender}
                >
                  <option value="">Select</option>
                  <option value="male">Male</option>
                  <option value="female">Female</option>
                  <option value="other">Other</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Date of Birth</label>
                <DatePicker 
                  onChange={onChange} 
                  format={"YYYY-MM-DD"} 
                  className="w-full"
                  defaultValue={moment(staticData.dob)}
                />
              </div>
            </div>

            {/* About Me */}
            <div className="mb-8">
              <h3 className="text-lg font-medium text-gray-700 mb-4">About Me</h3>
              <textarea 
                defaultValue={staticData.biography} 
                {...register("biography")} 
                className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                rows={5}
              />
            </div>

            {/* Clinic Info */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              <div>
                <h3 className="text-lg font-medium text-gray-700 mb-4">Clinic Info</h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Clinic Name</label>
                    <input 
                      defaultValue={staticData.clinicName} 
                      {...register("clinicName")} 
                      className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Clinic Address</label>
                    <input 
                      defaultValue={staticData.clinicAddress} 
                      {...register("clinicAddress")} 
                      className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>
              </div>
              
              <div>
                <h3 className="text-lg font-medium text-gray-700 mb-4">Contact Details</h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Address</label>
                    <input 
                      defaultValue={staticData.address} 
                      {...register("address")} 
                      className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">City</label>
                      <input 
                        defaultValue={staticData.city} 
                        {...register("city")} 
                        className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">State</label>
                      <input 
                        defaultValue={staticData.state} 
                        {...register("state")} 
                        className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Country</label>
                      <input 
                        defaultValue={staticData.country} 
                        {...register("country")} 
                        className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Postal Code</label>
                      <input 
                        defaultValue={staticData.postalCode} 
                        {...register("postalCode")} 
                        className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Pricing */}
            <div className="mb-8">
              <h3 className="text-lg font-medium text-gray-700 mb-4">Pricing</h3>
              <div className="w-full md:w-1/2">
                <label className="block text-sm font-medium text-gray-700 mb-1">30 Min Fee</label>
                <input 
                  defaultValue={staticData.price} 
                  {...register("price")} 
                  type="number"
                  className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>

            {/* Services and Specialization */}
            <div className="mb-8">
              <h3 className="text-lg font-medium text-gray-700 mb-4">Services and Specialization</h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Services</label>
                  <Select
                    mode="multiple"
                    allowClear
                    className="w-full"
                    placeholder="Please select"
                    value={selectedItems}
                    onChange={setSelectedItems}
                    options={doctorSpecialistOptions}
                    defaultValue={staticData.services?.split(',')}
                  />
                  <p className="text-xs text-gray-500 mt-1">Note: Type & Press enter to add new services</p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Specialization</label>
                  <input 
                    defaultValue={staticData.specialization} 
                    {...register("specialization")} 
                    className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Enter Specialization"
                  />
                  <p className="text-xs text-gray-500 mt-1">Note: Type & Press enter to add new specialization</p>
                </div>
              </div>
            </div>

            {/* Education */}
            <div className="mb-8">
              <h3 className="text-lg font-medium text-gray-700 mb-4">Education</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Degree</label>
                  <input 
                    defaultValue={staticData.degree} 
                    {...register("degree")} 
                    className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">College/Institute</label>
                  <input 
                    defaultValue={staticData.college} 
                    {...register("college")} 
                    className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Year of Completion</label>
                  <input 
                    defaultValue={staticData.completionYear} 
                    {...register("completionYear")} 
                    className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>
            </div>

            {/* Experience */}
            <div className="mb-8">
              <h3 className="text-lg font-medium text-gray-700 mb-4">Experience</h3>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Hospital Name</label>
                  <input 
                    defaultValue={staticData.experienceHospitalName} 
                    {...register("experienceHospitalName")} 
                    className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">From</label>
                  <input 
                    defaultValue={staticData.expericenceStart} 
                    {...register("expericenceStart")} 
                    className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">To</label>
                  <input 
                    defaultValue={staticData.expericenceEnd} 
                    {...register("expericenceEnd")} 
                    className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Designation</label>
                  <input 
                    defaultValue={staticData.designation} 
                    {...register("designation")} 
                    className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>
            </div>

            {/* Awards */}
            <div className="mb-8">
              <h3 className="text-lg font-medium text-gray-700 mb-4">Awards</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Awards</label>
                  <input 
                    defaultValue={staticData.award} 
                    {...register("award")} 
                    className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Year</label>
                  <input 
                    defaultValue={staticData.awardYear} 
                    {...register("awardYear")} 
                    className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>
            </div>

            {/* Registrations */}
            <div className="mb-8">
              <h3 className="text-lg font-medium text-gray-700 mb-4">Registrations</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Registrations</label>
                  <input 
                    defaultValue={staticData.registration} 
                    {...register("registration")} 
                    className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Year</label>
                  <input 
                    defaultValue={staticData.year} 
                    {...register("year")} 
                    className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>
            </div>

            {/* Submit Button */}
            <div className="flex justify-end">
              <Button 
                htmlType="submit" 
                type="primary" 
                size="large" 
                loading={isLoading}
                className="bg-blue-600 hover:bg-blue-700 px-6 py-3 rounded-md text-white font-medium"
              >
                {isLoading ? 'Saving...' : 'Save Changes'}
              </Button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default DoctorProfileSetting;