'use client';
import { useState } from 'react';
import { Button, Form, Input, message } from 'antd';
import DashboardSidebar from '@/components/Dashboard/Sidebar';
import { LockOutlined } from '@ant-design/icons';

const ChangePasswordPage = () => {
  const [form] = Form.useForm();
  const [isLoading, setIsLoading] = useState(false);

  const onFinish = (values: any) => {
    setIsLoading(true);
    console.log('Password change submitted:', values);
    // Simulate API call
    setTimeout(() => {
      message.success('Password changed successfully!');
      form.resetFields();
      setIsLoading(false);
    }, 1500);
  };

  return (
    <div className="flex min-h-screen bg-gray-50">
      {/* Fixed Sidebar */}
       <div className="sm:w-64 sm:fixed h-full bg-white shadow z-10 overflow-auto scrollbar-hide">
        <DashboardSidebar />
      </div>
      
      {/* Main Content Area */}
      <div className="sm:ml-64 ml-2 flex-1 p-8">
        <div className="max-w-2xl mx-auto">
          <div className="bg-white rounded-lg shadow p-8">
            <div className="text-center mb-8">
              <div className="mx-auto w-16 h-16 rounded-full bg-blue-100 flex items-center justify-center mb-4">
                <LockOutlined className="text-2xl text-blue-600" />
              </div>
              <h1 className="text-2xl font-bold text-gray-800">Change Your Password</h1>
              <p className="text-gray-600 mt-2">
                Ensure your account security by updating your password regularly
              </p>
            </div>

            <Form
              form={form}
              name="change_password"
              onFinish={onFinish}
              layout="vertical"
              className="space-y-6"
            >
              <Form.Item
                name="currentPassword"
                label="Current Password"
                rules={[
                  { required: true, message: 'Please input your current password!' },
                  { min: 6, message: 'Password must be at least 6 characters!' }
                ]}
              >
                <Input.Password 
                  size="large"
                  placeholder="Enter current password"
                  prefix={<LockOutlined className="text-gray-300" />}
                />
              </Form.Item>

              <Form.Item
                name="newPassword"
                label="New Password"
                rules={[
                  { required: true, message: 'Please input your new password!' },
                  { min: 8, message: 'Password must be at least 8 characters!' }
                ]}
                hasFeedback
              >
                <Input.Password 
                  size="large"
                  placeholder="Enter new password"
                  prefix={<LockOutlined className="text-gray-300" />}
                />
              </Form.Item>

              <Form.Item
                name="confirmPassword"
                label="Confirm New Password"
                dependencies={['newPassword']}
                hasFeedback
                rules={[
                  { required: true, message: 'Please confirm your new password!' },
                  ({ getFieldValue }) => ({
                    validator(_, value) {
                      if (!value || getFieldValue('newPassword') === value) {
                        return Promise.resolve();
                      }
                      return Promise.reject(new Error('The two passwords do not match!'));
                    },
                  }),
                ]}
              >
                <Input.Password 
                  size="large"
                  placeholder="Confirm new password"
                  prefix={<LockOutlined className="text-gray-300" />}
                />
              </Form.Item>

              <Form.Item className="text-center">
                <Button 
                  type="primary" 
                  htmlType="submit" 
                  size="large"
                  loading={isLoading}
                  className="w-full max-w-xs bg-blue-600 hover:bg-blue-700"
                >
                  Update Password
                </Button>
              </Form.Item>
            </Form>

            <div className="mt-6 text-center text-sm text-gray-500">
              <p>Make sure your new password is strong and unique</p>
              <p className="mt-1">Avoid using personal information or common words</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChangePasswordPage;