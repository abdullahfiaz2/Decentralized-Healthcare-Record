'use client';
import { useState } from 'react';
import { Badge, Button, Card, Tag, Modal, Descriptions, Divider, message } from 'antd';
import DashboardSidebar from '@/components/Dashboard/Sidebar';
import { 
  FaCalendarAlt, 
  FaClock, 
  FaUserMd, 
  FaMapMarkerAlt,
  FaFileMedical,
  FaCheckCircle,
  FaTimesCircle,
  FaIdCard,
  FaPhone,
  FaEnvelope,
  FaNotesMedical
} from 'react-icons/fa';
import moment from 'moment';

const MyBookingsPage = () => {
  const [activeTab, setActiveTab] = useState<'upcoming' | 'past'>('upcoming');
  const [selectedBooking, setSelectedBooking] = useState<any>(null);
  const [isModalVisible, setIsModalVisible] = useState(false);
  
  // Mock booking data
  const bookings = {
    upcoming: [
      {
        id: '1',
        doctor: {
          name: 'Dr. Sarah Johnson',
          specialty: 'Cardiologist',
          image: '/doctor1.jpg',
          phone: '+1 555-123-4567',
          email: 's.johnson@medicalcenter.com'
        },
        date: '2023-12-15',
        time: '10:00 AM',
        status: 'confirmed',
        location: 'City Medical Center, Room 302',
        address: '123 Medical Drive, New York, NY 10001',
        notes: 'Annual heart checkup',
        symptoms: 'Occasional chest discomfort',
        bookingId: 'APT-2023-0015',
        paymentStatus: 'Paid ($150)',
        duration: '30 minutes'
      },
      {
        id: '2',
        doctor: {
          name: 'Dr. Michael Chen',
          specialty: 'Dermatologist',
          image: '/doctor2.jpg',
          phone: '+1 555-987-6543',
          email: 'm.chen@skincareclinic.com'
        },
        date: '2023-12-20',
        time: '2:30 PM',
        status: 'pending',
        location: 'Skin Care Clinic, Main Wing',
        address: '456 Dermatology Ave, Boston, MA 02115',
        notes: 'Follow-up for skin treatment',
        symptoms: 'Persistent rash on arms',
        bookingId: 'APT-2023-0016',
        paymentStatus: 'Pending ($75 copay)',
        duration: '45 minutes'
      }
    ],
    past: [
      {
        id: '3',
        doctor: {
          name: 'Dr. Emily Wilson',
          specialty: 'Pediatrician',
          image: '/doctor3.jpg',
          phone: '+1 555-456-7890',
          email: 'e.wilson@childrenshospital.com'
        },
        date: '2023-11-10',
        time: '9:15 AM',
        status: 'completed',
        location: 'Childrens Hospital, Clinic B',
        address: '789 Pediatrics Lane, Chicago, IL 60601',
        notes: 'Vaccination appointment',
        symptoms: 'Routine immunization',
        bookingId: 'APT-2023-0014',
        paymentStatus: 'Paid ($50)',
        duration: '20 minutes',
        diagnosis: 'Administered flu vaccine',
        prescription: 'None required'
      }
    ]
  };

  const showBookingDetails = (booking: any) => {
    setSelectedBooking(booking);
    setIsModalVisible(true);
  };

  const closeModal = () => {
    setIsModalVisible(false);
    setSelectedBooking(null);
  };

  const cancelBooking = (id: string) => {
    message.success(`Appointment #${id} cancelled`);
    // In a real app, you would call an API here
  };

  return (
    <div className="flex min-h-screen bg-gray-50">
      {/* Fixed Sidebar */}
      <div className=" sm:w-64 sm:fixed h-full bg-white shadow z-10 overflow-auto scrollbar-hide">
        <DashboardSidebar />
      </div>
      {/* Main Content Area */}
      <div className="sm:ml-64 ml-2 flex-1 p-8">
        <div className="max-w-6xl mx-auto">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-2xl font-bold text-gray-800">My Appointments</h1>
            <div className="flex gap-2">
              <Button 
                type={activeTab === 'upcoming' ? 'primary' : 'default'}
                onClick={() => setActiveTab('upcoming')}
              >
                Upcoming
              </Button>
              <Button 
                type={activeTab === 'past' ? 'primary' : 'default'}
                onClick={() => setActiveTab('past')}
              >
                Past Appointments
              </Button>
            </div>
          </div>

          {bookings[activeTab].length === 0 ? (
            <Card className="text-center py-10">
              <p className="text-gray-500 text-lg">
                No {activeTab} appointments found
              </p>
              {activeTab === 'upcoming' && (
                <Button type="primary" className="mt-4">
                  Book an Appointment
                </Button>
              )}
            </Card>
          ) : (
            <div className="space-y-4">
              {bookings[activeTab].map(booking => (
                <Card key={booking.id} className="hover:shadow-lg transition-shadow">
                  <div className="flex flex-col md:flex-row gap-6">
                    {/* Doctor Info */}
                    <div className="flex items-start gap-4 flex-1">
                      <div className="w-16 h-16 rounded-full bg-blue-100 flex items-center justify-center">
                        <FaUserMd className="text-2xl text-blue-600" />
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold">{booking.doctor.name}</h3>
                        <p className="text-gray-600">{booking.doctor.specialty}</p>
                        
                        <div className="flex flex-wrap gap-2 mt-3">
                          <Tag icon={<FaCalendarAlt />} color="blue">
                            {moment(booking.date).format('MMM Do, YYYY')}
                          </Tag>
                          <Tag icon={<FaClock />} color="geekblue">
                            {booking.time}
                          </Tag>
                          <Tag icon={<FaMapMarkerAlt />} color="purple">
                            {booking.location}
                          </Tag>
                          {booking.status === 'confirmed' && (
                            <Tag icon={<FaCheckCircle />} color="green">
                              Confirmed
                            </Tag>
                          )}
                          {booking.status === 'pending' && (
                            <Tag icon={<FaClock />} color="orange">
                              Pending
                            </Tag>
                          )}
                          {booking.status === 'completed' && (
                            <Tag icon={<FaCheckCircle />} color="cyan">
                              Completed
                            </Tag>
                          )}
                        </div>
                      </div>
                    </div>
                    
                    {/* Actions */}
                    <div className="flex flex-col gap-2">
                      <Button 
                        type="primary" 
                        icon={<FaFileMedical />}
                        onClick={() => showBookingDetails(booking)}
                        className="flex items-center gap-1"
                      >
                        View Details
                      </Button>
                      {activeTab === 'upcoming' && booking.status !== 'completed' && (
                        <Button 
                          danger 
                          onClick={() => cancelBooking(booking.id)}
                          className="flex items-center gap-1"
                        >
                          Cancel Appointment
                        </Button>
                      )}
                    </div>
                  </div>
                  
                  {booking.notes && (
                    <div className="mt-4 pt-4 border-t border-gray-100">
                      <p className="text-gray-600">
                        <span className="font-medium">Notes:</span> {booking.notes}
                      </p>
                    </div>
                  )}
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Booking Details Modal */}
      <Modal
        title={<span className="text-xl font-semibold">Appointment Details</span>}
        width={800}
        visible={isModalVisible}
        onCancel={closeModal}
        footer={[
          <Button key="close" onClick={closeModal}>
            Close
          </Button>
        ]}
      >
        {selectedBooking && (
          <div className="space-y-6">
            <div className="flex items-start gap-6">
              <div className="w-20 h-20 rounded-full bg-blue-100 flex items-center justify-center">
                <FaUserMd className="text-3xl text-blue-600" />
              </div>
              <div>
                <h3 className="text-xl font-semibold">{selectedBooking.doctor.name}</h3>
                <p className="text-lg text-gray-600">{selectedBooking.doctor.specialty}</p>
                <div className="flex gap-2 mt-2">
                  <Tag color="blue" icon={<FaIdCard />}>
                    {selectedBooking.bookingId}
                  </Tag>
                  <Tag color={selectedBooking.status === 'confirmed' ? 'green' : 
                            selectedBooking.status === 'completed' ? 'cyan' : 'orange'} 
                      icon={selectedBooking.status === 'pending' ? <FaClock /> : <FaCheckCircle />}>
                    {selectedBooking.status}
                  </Tag>
                </div>
              </div>
            </div>

            <Divider />

            <Descriptions bordered column={2}>
              <Descriptions.Item label="Date" span={2}>
                <div className="flex items-center gap-2">
                  <FaCalendarAlt className="text-blue-500" />
                  {moment(selectedBooking.date).format('dddd, MMMM Do YYYY')}
                </div>
              </Descriptions.Item>
              <Descriptions.Item label="Time">
                <div className="flex items-center gap-2">
                  <FaClock className="text-blue-500" />
                  {selectedBooking.time}
                </div>
              </Descriptions.Item>
              <Descriptions.Item label="Duration">
                {selectedBooking.duration}
              </Descriptions.Item>
              <Descriptions.Item label="Location" span={2}>
                <div className="flex items-start gap-2">
                  <FaMapMarkerAlt className="text-blue-500 mt-1" />
                  <div>
                    <div>{selectedBooking.location}</div>
                    <div className="text-gray-600 text-sm">{selectedBooking.address}</div>
                  </div>
                </div>
              </Descriptions.Item>
              <Descriptions.Item label="Doctor Contact" span={2}>
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <FaPhone className="text-blue-500" />
                    {selectedBooking.doctor.phone}
                  </div>
                  <div className="flex items-center gap-2">
                    <FaEnvelope className="text-blue-500" />
                    {selectedBooking.doctor.email}
                  </div>
                </div>
              </Descriptions.Item>
              <Descriptions.Item label="Payment Status">
                {selectedBooking.paymentStatus}
              </Descriptions.Item>
              <Descriptions.Item label="Symptoms">
                {selectedBooking.symptoms}
              </Descriptions.Item>
              {selectedBooking.status === 'completed' && (
                <>
                  <Descriptions.Item label="Diagnosis">
                    {selectedBooking.diagnosis}
                  </Descriptions.Item>
                  <Descriptions.Item label="Prescription">
                    {selectedBooking.prescription}
                  </Descriptions.Item>
                </>
              )}
              <Descriptions.Item label="Notes" span={2}>
                <div className="flex items-start gap-2">
                  <FaNotesMedical className="text-blue-500 mt-1" />
                  {selectedBooking.notes}
                </div>
              </Descriptions.Item>
            </Descriptions>
          </div>
        )}
      </Modal>
    </div>
  );
};

export default MyBookingsPage;