"use client";
import { useState, useEffect } from "react";
import { Space, Tag, Button, Empty, message, TimePicker } from "antd";
import { FaWindowClose, FaPlus, FaBars } from "react-icons/fa";
import DashboardSidebar from "@/components/Dashboard/Sidebar";
import dayjs, { Dayjs } from "dayjs";
import type { TimePickerProps } from "antd";

interface TimeSlot {
  id: number;
  startTime?: string;
  endTime?: string;
  doctorTimeSlotId?: string;
}

const SchedulePage = () => {
  const [key, setKey] = useState("sunday");
  const [timeSlot, setTimeSlot] = useState<TimeSlot[]>([]);
  const [addTimeSlot, setAddTimeSlot] = useState<TimeSlot[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [mobileSidebarVisible, setMobileSidebarVisible] = useState(false);
  const [isMobile, setIsMobile] = useState(false);

  // Static mock data
  const mockData = [
    {
      id: 1,
      day: "sunday",
      maximumPatient: 10,
      timeSlot: [
        { id: 1, startTime: "09:00", endTime: "10:00" },
        { id: 2, startTime: "11:00", endTime: "12:00" },
      ],
    },
    {
      id: 2,
      day: "monday",
      maximumPatient: 15,
      timeSlot: [
        { id: 3, startTime: "10:00", endTime: "11:00" },
        { id: 4, startTime: "14:00", endTime: "15:00" },
      ],
    },
  ];

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768);
    };
    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  useEffect(() => {
    const dayData = mockData.find((item) => item.day === key);
    if (dayData) {
      setTimeSlot(dayData.timeSlot);
    }
  }, [key]);

  const removeTimeSlot = (id: number) => {
    setTimeSlot(timeSlot.filter((item) => item.id !== id));
    message.info("Time slot removed");
  };

  const addField = (e: React.MouseEvent) => {
    e.preventDefault();
    const newId = timeSlot.length > 0 ? Math.max(...timeSlot.map((item) => item.id)) + 1 : 1;
    setTimeSlot([...timeSlot, { id: newId }]);
  };

  const removeFromAddTimeSlot = (id: number) => {
    setAddTimeSlot(addTimeSlot.filter((item) => item.id !== id));
  };

  const addInAddTimeSlot = (e: React.MouseEvent) => {
    e.preventDefault();
    const newId = addTimeSlot.length > 0 ? Math.max(...addTimeSlot.map((item) => item.id)) + 1 : 1;
    setAddTimeSlot([...addTimeSlot, { id: newId }]);
  };

  const handleEditOk = () => {
    message.success("Time slots updated successfully!");
    setIsEditModalOpen(false);
  };

  const handleOk = () => {
    message.success("Time slots added successfully!");
    setIsModalOpen(false);
  };

  const handleTimeChange = (
    time: Dayjs | null,
    timeString: string | string[],
    index: number,
    field: "startTime" | "endTime",
    setter: React.Dispatch<React.SetStateAction<TimeSlot[]>>
  ) => {
    const timeValue = Array.isArray(timeString) ? timeString[0] : timeString;
    if (timeValue) {
      setter((prev: TimeSlot[]) => {
        const updated = [...prev];
        if (!updated[index]) {
          updated[index] = { id: index + 1 };
        }
        updated[index][field] = timeValue;
        return updated;
      });
    }
  };

  const handleDaySelect = (day: string) => {
    setKey(day);
  };

  const renderTimeSlots = () => (
    <Space size={[0, "small"]} wrap>
      {timeSlot.map((time) => (
        <Tag key={time.id} closable onClose={() => removeTimeSlot(time.id)}>
          {time.startTime} - {time.endTime}
        </Tag>
      ))}
    </Space>
  );

  return (
    <div className="flex min-h-screen bg-gray-50">
      
        <div className=" sm:w-64 sm:fixed h-full bg-white shadow z-10 overflow-auto scrollbar-hide">
        <DashboardSidebar />
      </div>
      {/* Main Content */}
      <div className={`${isMobile ? 'w-full' : 'ml-64'} flex-1 p-4 md:p-8`}>
        <div className="bg-white rounded-lg shadow p-4 md:p-6 min-h-[50vh] ">
          <h2 className="text-xl md:text-2xl font-bold text-gray-800 mb-4 md:mb-6">
            Schedule Timings
          </h2>

          {/* Day Selection */}
          <div className="overflow-x-auto pb-2 mb-4 md:mb-6">
            <div className="flex gap-2 w-max">
              {['sunday','monday','tuesday','wednesday','thursday','friday','saturday'].map(day => (
                <Button
                  key={day}
                  type={key === day ? "primary" : "default"}
                  onClick={() => handleDaySelect(day)}
                  size={isMobile ? "small" : "middle"}
                >
                  {day.charAt(0).toUpperCase() + day.slice(1).substring(0, 2)}
                </Button>
              ))}
            </div>
          </div>

          {/* Time Slots */}
          <div className="mb-4 md:mb-6">
            {timeSlot.length === 0 ? (
              <Empty description="No schedule for this day" />
            ) : (
              renderTimeSlots()
            )}
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col md:flex-row gap-2 md:gap-4">
            <Button 
              type="primary" 
              onClick={() => setIsEditModalOpen(true)}
              block={isMobile}
            >
              Edit Slots
            </Button>
            <Button 
              type="primary" 
              onClick={() => setIsModalOpen(true)}
              block={isMobile}
            >
              Add Slots
            </Button>
          </div>
        </div>
      </div>

      {/* Edit Time Slots Modal */}
      {isEditModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg w-full max-w-md md:max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="p-4 md:p-6">
              <h3 className="text-lg md:text-xl font-bold mb-4">Edit Time Slots</h3>
              <form>
                <div className="space-y-3 md:space-y-4">
                  {timeSlot.map((item, index) => (
                    <div key={index} className="flex flex-col md:flex-row md:items-center gap-3">
                      <div className="grid grid-cols-2 gap-3 w-full">
                        <div>
                          <label className="block text-sm md:text-base mb-1 md:mb-2">Start</label>
                          <TimePicker
                            value={item.startTime ? dayjs(item.startTime, 'HH:mm') : null}
                            format="HH:mm"
                            onChange={(time: Dayjs | null, timeString: string | string[]) => 
                              handleTimeChange(time, timeString, index, "startTime", setTimeSlot)
                            }
                            size={isMobile ? "small" : "middle"}
                          />
                        </div>
                        <div>
                          <label className="block text-sm md:text-base mb-1 md:mb-2">End</label>
                          <TimePicker
                            value={item.endTime ? dayjs(item.endTime, 'HH:mm') : null}
                            format="HH:mm"
                            onChange={(time: Dayjs | null, timeString: string | string[]) => 
                              handleTimeChange(time, timeString, index, "endTime", setTimeSlot)
                            }
                            size={isMobile ? "small" : "middle"}
                          />
                        </div>
                      </div>
                      <Button
                        danger
                        icon={<FaWindowClose />}
                        onClick={() => removeTimeSlot(item.id)}
                        size={isMobile ? "small" : "middle"}
                      />
                    </div>
                  ))}
                </div>

                <div className="mt-3 md:mt-4">
                  <Button 
                    type="primary" 
                    icon={<FaPlus />} 
                    onClick={addField}
                    size={isMobile ? "small" : "middle"}
                  >
                    Add More
                  </Button>
                </div>

                <div className="flex justify-end gap-2 mt-4 md:mt-6">
                  <Button 
                    onClick={() => setIsEditModalOpen(false)}
                    size={isMobile ? "small" : "middle"}
                  >
                    Cancel
                  </Button>
                  <Button 
                    type="primary" 
                    onClick={handleEditOk}
                    size={isMobile ? "small" : "middle"}
                  >
                    Save
                  </Button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Add Time Slots Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg w-full max-w-md md:max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="p-4 md:p-6">
              <h3 className="text-lg md:text-xl font-bold mb-4">Add Time Slots</h3>
              <form>
                <div className="space-y-3 md:space-y-4">
                  {addTimeSlot.map((item, index) => (
                    <div key={index} className="flex flex-col md:flex-row md:items-center gap-3">
                      <div className="grid grid-cols-2 gap-3 w-full">
                        <div>
                          <label className="block text-sm md:text-base mb-1 md:mb-2">Start</label>
                          <TimePicker
                            format="HH:mm"
                            onChange={(time: Dayjs | null, timeString: string | string[]) => 
                              handleTimeChange(time, timeString, index, "startTime", setAddTimeSlot)
                            }
                            size={isMobile ? "small" : "middle"}
                          />
                        </div>
                        <div>
                          <label className="block text-sm md:text-base mb-1 md:mb-2">End</label>
                          <TimePicker
                            format="HH:mm"
                            onChange={(time: Dayjs | null, timeString: string | string[]) => 
                              handleTimeChange(time, timeString, index, "endTime", setAddTimeSlot)
                            }
                            size={isMobile ? "small" : "middle"}
                          />
                        </div>
                      </div>
                      <Button
                        danger
                        icon={<FaWindowClose />}
                        onClick={() => removeFromAddTimeSlot(item.id)}
                        size={isMobile ? "small" : "middle"}
                      />
                    </div>
                  ))}
                </div>

                <div className="mt-3 md:mt-4">
                  <Button 
                    type="primary" 
                    icon={<FaPlus />} 
                    onClick={addInAddTimeSlot}
                    size={isMobile ? "small" : "middle"}
                  >
                    Add More
                  </Button>
                </div>

                <div className="flex justify-end gap-2 mt-4 md:mt-6">
                  <Button 
                    onClick={() => setIsModalOpen(false)}
                    size={isMobile ? "small" : "middle"}
                  >
                    Cancel
                  </Button>
                  <Button 
                    type="primary" 
                    onClick={handleOk}
                    size={isMobile ? "small" : "middle"}
                  >
                    Save
                  </Button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SchedulePage;