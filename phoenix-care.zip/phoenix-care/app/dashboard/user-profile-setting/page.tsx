"use client";
import { useState, useEffect } from "react";
import moment from "moment";
import { useForm } from "react-hook-form";
import Link from "next/link";
import Image from "next/image";
import { DatePicker, message } from "antd";
import DashboardSidebar from "@/components/Dashboard/Sidebar";
import avatar from "@/public/images/avatar.jpg";

// Static data for blood group options
const bloodGrupOptions = [
  { value: "A+", label: "A+" },
  { value: "A-", label: "A-" },
  { value: "B+", label: "B+" },
  { value: "B-", label: "B-" },
  { value: "AB+", label: "AB+" },
  { value: "AB-", label: "AB-" },
  { value: "O+", label: "O+" },
  { value: "O-", label: "O-" },
];

type FormData = {
  firstName: string;
  lastName: string;
  mobile: string;
  city: string;
  state: string;
  zipCode: string;
  country: string;
  address: string;
};

const PatientProfileSetting = () => {
  const { register, handleSubmit } = useForm<FormData>();
  const [selectBloodGroup, setSelectBloodGroup] = useState("");
  const [selectValue, setSelectValue] = useState<Record<string, string>>({});
  const [date, setDate] = useState<string | null>(null);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [file, setFile] = useState<File | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Static data for demonstration
  const staticData = {
    id: "1",
    firstName: "John",
    lastName: "Doe",
    email: "john.doe@example.com",
    dateOfBirth: "1990-01-01",
    mobile: "1234567890",
    gender: "male",
    bloodGroup: "A+",
    city: "New York",
    state: "NY",
    zipCode: "10001",
    country: "USA",
    address: "123 Main Street",
    img: avatar,
  };

  const onChange = (
    date: moment.Moment | null,
    dateString: string | string[]
  ) => {
    if (typeof dateString === "string") {
      setDate(moment(dateString).format());
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setSelectValue({ ...selectValue, [e.target.name]: e.target.value });
    if (e.target.name === "bloodGroup") {
      setSelectBloodGroup(e.target.value);
    }
  };

  const onSubmit = (data: FormData) => {
    setIsLoading(true);
    console.log("Form submitted:", data);
    // Simulate API call
    setTimeout(() => {
      setIsLoading(false);
      message.success("Profile updated successfully!");
    }, 1500);
  };

  return (
    <div className="flex min-h-screen bg-gray-50">
      {/* Sidebar - Fixed width */}
    <div className="sm:w-64 sm:fixedh-full bg-white shadow z-10 overflow-auto scrollbar-hide">
        <DashboardSidebar />
      </div>

      {/* Main Content - Pushed right by sidebar width */}
      <div className="sm:ml-64 ml-2 flex-1 p-8">
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-2xl font-bold text-gray-800 mb-6">
            Update Your Information
          </h2>

          <form onSubmit={handleSubmit(onSubmit)}>
            {/* Avatar Section */}
            <div className="mb-8">
              <div className="flex items-center gap-4">
                <div className="relative">
                  <Image
                    src={selectedImage || staticData.img}
                    alt="Profile"
                    width={100}
                    height={100}
                    className="rounded-full border-2 border-gray-200"
                  />
                </div>
                <div>
                  <button
                    type="button"
                    className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition"
                  >
                    Change Avatar
                  </button>
                  <p className="text-sm text-gray-500 mt-2">
                    JPG, GIF or PNG. Max size of 2MB
                  </p>
                </div>
              </div>
            </div>

            {/* Personal Information */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  First Name <span className="text-red-500">*</span>
                </label>
                <input
                  defaultValue={staticData.firstName}
                  {...register("firstName")}
                  className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Last Name <span className="text-red-500">*</span>
                </label>
                <input
                  defaultValue={staticData.lastName}
                  {...register("lastName")}
                  className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Email <span className="text-red-500">*</span>
                </label>
                <input
                  defaultValue={staticData.email}
                  className="w-full px-3 py-2 border border-gray-300 rounded bg-gray-100 cursor-not-allowed"
                  disabled
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Date of Birth
                </label>
                <DatePicker
                  //   onChange={onChange}
                  format={"YYYY-MM-DD"}
                  className="w-full"
                  defaultValue={moment(staticData.dateOfBirth)}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Phone Number
                </label>
                <input
                  defaultValue={staticData.mobile}
                  {...register("mobile")}
                  className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Gender
                </label>
                <select
                  className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  onChange={handleChange}
                  name="gender"
                  defaultValue={staticData.gender}
                >
                  <option value="">Select</option>
                  <option value="male">Male</option>
                  <option value="female">Female</option>
                  <option value="other">Other</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Blood Group
                </label>
                <select
                  className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  onChange={handleChange}
                  name="bloodGroup"
                  value={selectBloodGroup || staticData.bloodGroup}
                >
                  {bloodGrupOptions.map((option, index) => (
                    <option key={index} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Address Information */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  City
                </label>
                <input
                  defaultValue={staticData.city}
                  {...register("city")}
                  className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  State
                </label>
                <input
                  defaultValue={staticData.state}
                  {...register("state")}
                  className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Zip Code
                </label>
                <input
                  defaultValue={staticData.zipCode}
                  {...register("zipCode")}
                  className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Country
                </label>
                <input
                  defaultValue={staticData.country}
                  {...register("country")}
                  className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Address
                </label>
                <input
                  defaultValue={staticData.address}
                  {...register("address")}
                  className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>

            {/* Submit Button */}
            <div className="flex justify-center">
              <button
                type="submit"
                disabled={isLoading}
                className="px-6 py-3 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isLoading ? "Updating..." : "Save Changes"}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default PatientProfileSetting;
