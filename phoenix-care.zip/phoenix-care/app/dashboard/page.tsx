'use client';
import { useContext, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from'@/app/Context/AuthContext';
import DashboardSidebar from '@/components/Dashboard/Sidebar';
import PatientDashboard from '@/components/Dashboard/PatientDashboard';
import DoctorDashboard from '@/components/Dashboard/DoctorDashboard';

export default function DashboardPage() {
  const { user, role, loading } = useAuth()
  const router = useRouter();

  useEffect(() => {
    if (!loading && !user) {
      router.push('/login');
    }
  }, [loading, user, router]);

  if (loading) {
    return <div className="flex justify-center items-center h-screen">Loading...</div>;
  }


  if (!user) {
    router.push('/login');
    return null;
  }

  return (
   <div className="flex h-screen overflow-hidden">
      {/* Sidebar - Hidden on mobile, visible on desktop */}
      <div className="sm:w-64 sm:fixed h-full bg-white shadow z-10 overflow-y-auto">
        <DashboardSidebar />
      </div>
      
      {/* Main Content - Full width on mobile, offset on desktop */}
      <div className="flex-1  overflow-y-auto">
        {role === 'doctor' ? <DoctorDashboard /> : <PatientDashboard />}
      </div>
    </div>
  );
}