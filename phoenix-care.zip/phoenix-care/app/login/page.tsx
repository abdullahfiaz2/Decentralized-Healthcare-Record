"use client";
import Image from "next/image";
import Link from "next/link";
import { useState ,useEffect} from "react";
import { useRouter } from "next/navigation";
import { signInWithEmailAndPassword, signInWithPopup,onAuthStateChanged } from "firebase/auth";
import { auth, googleProvider } from "@/lib/firebase";
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import RoleSelectionModal from '@/components/RoleSelectionModal';
import { useAuth } from '@/app/Context/AuthContext';

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [showRoleModal, setShowRoleModal] = useState(false);
    const { user, isNewUser } = useAuth();
  const [googleUser, setGoogleUser] = useState<any>(null);
  const router = useRouter();

  useEffect(() => {
    if (user && !isNewUser) {
      router.push('/dashboard');
    } else if (user && isNewUser) {
      setShowRoleModal(true);
    }
  }, [user, isNewUser, router])
  const handleGoogleLogin = async () => {
    try {
      setLoading(true);
      const result = await signInWithPopup(auth, googleProvider);
      
      // Check if user exists in Firestore
      const userDoc = await getDoc(doc(db, "users", result.user.uid));
      
      if (userDoc.exists()) {
        // Existing user - proceed to dashboard
        router.push('/dashboard');
      } else {
        // New user - show role selection
        setGoogleUser({
          uid: result.user.uid,
          displayName: result.user.displayName,
          email: result.user.email
        });
        setShowRoleModal(true);
      }
    } catch (error: any) {
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };
 const handleRoleSelected = async (role: string) => {
    try {
      setLoading(true);
      if (!user) throw new Error('No user logged in');
      
      await setDoc(doc(db, "users", user.uid), {
        fullName: user.displayName,
        email: user.email,
        role: role,
        createdAt: new Date(),
      });
      
      setShowRoleModal(false);
      router.push('/dashboard');
    } catch (error) {
      setError('Failed to save user role');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };


 const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError("");
    try {
      setLoading(true);
      await signInWithEmailAndPassword(auth, email, password);
      router.push('/dashboard');
    } catch (error: unknown) {
      setError(error instanceof Error ? error.message : "Login failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <section className="flex items-center justify-center min-h-screen bg-gray-100">
      <div className="container max-w-4xl bg-white shadow-lg rounded-lg p-6 md:p-12">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="hidden md:flex flex-col items-center text-center">
            <Link href="">
              <Image
                src="/images/logo.jpg"
                alt="Next Learning"
                width={50}
                height={50}
                style={{ filter: "invert(1)" }}
              />
            </Link>
            <h2 className="text-xl font-bold text-gray-800 my-4">
              Phoenix Care 
            </h2>
            <Image
              src="/images/Doctor.png"
              width={200}
              height={200}
              alt="Mascot"
            />
            <p className="text-gray-600 mt-4">
            Take Control of Your Health, One Block at a Time
            </p>
          </div>
          <div className="flex flex-col p-6">
            <h2 className="text-3xl font-bold text-gray-800 mb-6">Log in</h2>
            <div className="space-y-4">
              {/* Update Google Login button */}
              <button
                type="button"
                onClick={handleGoogleLogin}
                disabled={loading}
                className="w-full flex items-center justify-center bg-gray-100 text-gray-700 font-bold py-2 px-4 rounded disabled:opacity-50"
              >
                <Image
                  src="https://files.codebasics.io/v3/images/google.svg"
                  width={20}
                  height={20}
                  alt="Google"
                  className="mr-2"
                />
                {loading ? "Processing..." : "Log in with Google"}
              </button>
            </div>
            <form onSubmit={handleSubmit} className="mt-6 space-y-4">
              <div>
                <label className="block text-gray-700 font-bold">
                  Email Address
                </label>
                <input
                  type="email"
                  className="w-full p-2 border rounded"
                  value={email}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setEmail(e.target.value)}
                  required
                />
              </div>
              <div>
                <label className="block text-gray-700 font-bold">
                  Password
                </label>
                <input
                  type="password"
                  className="w-full p-2 border rounded"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
              </div>
              <div className="text-right">
                <Link href="" className="text-blue-600 hover:underline">
                  Forgot Password?
                </Link>
              </div>
              <button
        type="submit"
        disabled={loading}
        className="w-full bg-green-600 text-white font-bold py-2 px-4 rounded disabled:opacity-50"
      >
        {loading ? "Logging In..." : "Login"}
      </button>
            </form>
            <div className="text-center mt-4 text-gray-600">
              <p>
                No Account?{" "}
                <Link
                  href="/register"
                  className="text-blue-600 hover:underline"
                >
                  Register
                </Link>
              </p>
              <p className="text-sm mt-4">
                By signing up, you agree to our{" "}
                <Link href="" className="text-blue-600 hover:underline">
                  Terms
                </Link>{" "}
                and{" "}
                <Link href="" className="text-blue-600 hover:underline">
                  Privacy Policy
                </Link>
                .
              </p>
            </div>
            
          </div>
        </div>
      </div>
        {showRoleModal && googleUser && (
        <RoleSelectionModal 
          onRoleSelected={handleRoleSelected}
          userData={googleUser}
        />
      )}
    </section>
  );
}
