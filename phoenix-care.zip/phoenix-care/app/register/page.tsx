"use client";
import { useState, FormEvent, ChangeEvent } from "react";
import Link from "next/link";
import Image from "next/image";
import { useRouter } from "next/navigation";
import {
  createUserWithEmailAndPassword,
  updateProfile,
  signInWithPopup,
} from "firebase/auth";
import { auth, db, googleProvider } from "@/lib/firebase";
import { doc, getDoc, setDoc } from 'firebase/firestore';
import RoleSelectionModal from '@/components/RoleSelectionModal';

export default function Register() {
  const router = useRouter();
  const [formData, setFormData] = useState({
    fullName: "",
    mobile: "",
    email: "",
    password: "",
    role: "",
    passwordConfirmation: "",
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
    const [showRoleModal, setShowRoleModal] = useState(false);
  const [googleUser, setGoogleUser] = useState<any>(null);
  const handleChange = (
    e: ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };


  const handleGoogleSignUp = async () => {
    try {
      setLoading(true);
      setError("");
      
      const result = await signInWithPopup(auth, googleProvider);
      
      // Check if user exists in Firestore
      const userDoc = await getDoc(doc(db, "users", result.user.uid));
      
      if (userDoc.exists()) {
        // Existing user - proceed to dashboard
        router.push('/dashboard');
      } else {
        // New user - show role selection
        setGoogleUser({
          uid: result.user.uid,
          displayName: result.user.displayName,
          email: result.user.email
        });
        setShowRoleModal(true);
      }
    } catch (err: any) {
      setError(err.message || "Google signup failed");
    } finally {
      setLoading(false);
    }
  };

    const handleRoleSelected = async (role: string) => {
    try {
      setLoading(true);
      // Save user data with selected role to Firestore
      await setDoc(doc(db, "users", googleUser.uid), {
        fullName: googleUser.displayName,
        email: googleUser.email,
        role: role,
        createdAt: new Date(),
      });
      
      setShowRoleModal(false);
      router.push('/dashboard');
    } catch (error) {
      setError('Failed to save user role');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };
  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError("");

    // Validation
    if (!formData.role) {
      setError("Please select your role");
      return;
    }

    if (formData.password !== formData.passwordConfirmation) {
      setError("Passwords do not match");
      return;
    }

    if (formData.password.length < 6) {
      setError("Password must be at least 6 characters");
      return;
    }

    try {
      setLoading(true);
      
      // 1. Create user with email/password
      const userCredential = await createUserWithEmailAndPassword(
        auth,
        formData.email,
        formData.password
      );

      // 2. Update user profile
      await updateProfile(userCredential.user, {
        displayName: formData.fullName,
      });

      // 3. Save additional user data to Firestore
      await setDoc(doc(db, "users", userCredential.user.uid), {
        fullName: formData.fullName,
        email: formData.email,
        mobile: formData.mobile,
        role: formData.role,
        createdAt: new Date(),
      });

      // 4. Redirect to dashboard
      router.push("/dashboard");

    } catch (err: any) {
      console.error("Registration error:", err);
      setError(err.message || "Registration failed");
    } finally {
      setLoading(false);
    }
  };
  return (
    <section className="flex items-center justify-center min-h-screen bg-gray-100">
      <div className="container max-w-4xl bg-white shadow-lg rounded-lg p-6 md:p-12">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
          <div className="hidden md:flex flex-col items-center text-center">
            <Link href="">
              <Image
                src="/images/logo.jpg"
                alt="Next Learning"
                width={70}
                height={60}
                style={{ filter: "invert(1)" }}
              />
            </Link>
            <h2 className="text-xl font-bold text-gray-800 my-8">
              Phoenix Care
            </h2>
            <Image
              src="/images/Doctor.png"
              width={300}
              height={300}
              alt="Mascot"
            />
            <p className="text-gray-600 mt-4">
              Take Control of Your Health, One Block at a Time
            </p>
          </div>
          {/* Right side */}
          <div className="flex flex-col p-6">
            <h2 className="text-2xl text-gray-900 font-extrabold my-2">
              Register
            </h2>

            {/* Social Login Buttons */}
            <div className="md:flex gap-3 justify-between mb-3">
              <div className="mb-3 md:mb-4 flex-1">
                <button
                  type="button"
                  onClick={handleGoogleSignUp}
                  disabled={loading}
                  className="btn bg-gray-100 shadow-none block w-full font-extrabold text-gray-900 py-3 flex items-center justify-center"
                >
                  <Image
                    src="https://files.codebasics.io/v3/images/google.svg"
                    alt="Google"
                    width={20}
                    height={20}
                    className="mr-5"
                  />
                  {loading ? "Processing..." : "Register with Google"}
                </button>
              </div>
            </div>

            {/* Registration Form */}
            <form onSubmit={handleSubmit} className="my-2" noValidate>
              <div className="grid grid-cols-1 gap-2">
                <div className="col-span-1">
                  <div className="mb-6">
                    <label
                      htmlFor="fullName"
                      className="block text-black font-bold mb-2"
                    >
                      Full Name <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none text-gray-600"
                      id="fullName"
                      name="fullName"
                      value={formData.fullName}
                      onChange={handleChange}
                      required
                    />
                  </div>
                </div>

                <div className="col-span-1">
                  <div className="mb-6">
                    <label
                      htmlFor="email"
                      className="block font-bold text-black  mb-2"
                    >
                      Enter your Email Address{" "}
                      <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="email"
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none text-gray-600"
                      id="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      required
                    />
                  </div>
                </div>

                <div className="col-span-1">
                  <div className="mb-6">
                    <label
                      htmlFor="role"
                      className="block font-bold text-black mb-2"
                    >
                      I’M <span className="text-red-500">*</span>
                    </label>
                    <select
                      id="role"
                      name="role"
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none text-gray-600"
                      value={formData.role}
                      onChange={handleChange}
                      required
                    >
                      <option value="">Select your role</option>
                      <option value="patient">Patient</option>
                      <option value="doctor">Doctor</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="col-span-1">
                    <div className="mb-6">
                      <label
                        htmlFor="password"
                        className="block font-bold text-black  mb-2"
                      >
                        Enter Password <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="password"
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none text-gray-500"
                        id="password"
                        name="password"
                        value={formData.password}
                        onChange={handleChange}
                        minLength={6}
                        required
                      />
                    </div>
                  </div>
                  <div className="col-span-1">
                    <div className="mb-6">
                      <label
                        htmlFor="passwordConfirmation"
                        className="block font-bold text-black  mb-2"
                      >
                        Retype Password <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="password"
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none text-gray-500"
                        id="passwordConfirmation"
                        name="passwordConfirmation"
                        value={formData.passwordConfirmation}
                        onChange={handleChange}
                        minLength={6}
                        required
                      />
                    </div>
                  </div>
                </div>

                <div className="col-span-1">
                  <div className="mb-6">
                    <button
                      type="submit"
                      disabled={loading}
                      className="w-full bg-green-600 text-white font-bold py-3 px-4 rounded-md disabled:opacity-50"
                    >
                      {loading ? "Creating Account..." : "Submit"}
                    </button>
                    <div className="md:flex justify-between">
                      <div>
                        <p className="mb-0 text-gray-900">Have an Account?</p>
                        <Link
                          href="/login"
                          className="text-blue-600 hover:underline"
                        >
                          Log in
                        </Link>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </form>

            <div className="text-center">
              <p className="text-sm text-gray-900 mt-2">
                By signing up, you agree to
                <br />
                our{" "}
                <a
                  href=""
                  className="font-extrabold text-gray-900 hover:text-blue-600"
                >
                  Terms and Conditions
                </a>{" "}
                and{" "}
                <a
                  href="https://codebasics.io/privacy-policy"
                  className="font-extrabold text-gray-900 hover:text-blue-600"
                >
                  Privacy Policy
                </a>
                .
              </p>
            </div>
          </div>
        </div>
      </div>
      {showRoleModal && googleUser && (
        <RoleSelectionModal 
          onRoleSelected={handleRoleSelected}
          userData={googleUser}
        />
      )}
    </section>
  );
}
