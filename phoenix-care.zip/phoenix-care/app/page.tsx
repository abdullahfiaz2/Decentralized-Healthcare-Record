// app/page.tsx
'use client';
import Link from 'next/link';
import Image from 'next/image';
import { FaPhone, FaCalendarAlt, FaMapMarkerAlt, FaClock, FaArrowRight, FaUser } from 'react-icons/fa';
import { useAuth } from '@/app/Context/AuthContext';
import { useRouter } from 'next/navigation';


export default function Home() {
   const { user, loading } = useAuth();
  const router = useRouter();

  const handleAuthClick = () => {
    if (user) {
      router.push('/dashboard');
    } else {
      router.push('/login');
    }
  };
  return (
    <div className="font-sans">
      {/* Header/Navbar */}
      <header className="bg-white shadow-md sticky top-0 z-50">
        <div className="container mx-auto px-6 py-4 flex justify-between items-center">
          <div className="flex items-center">
            <Image 
              src="/images/logo.jpg" 
              alt="Clinic Logo" 
              width={50} 
              height={50} 
              className="mr-3"
            />
            <span className="text-2xl font-bold text-blue-600">PhoenixCare</span>
          </div>
          
          <nav className="hidden md:flex space-x-8">
            <Link href="#home" className="text-gray-700 hover:text-blue-600 font-medium">Home</Link>
            <Link href="#about" className="text-gray-700 hover:text-blue-600 font-medium">About</Link>
            <Link href="#doctors" className="text-gray-700 hover:text-blue-600 font-medium">Doctors</Link>
            <Link href="#appointment" className="text-gray-700 hover:text-blue-600 font-medium">Appointment</Link>
            <Link href="#contact" className="text-gray-700 hover:text-blue-600 font-medium">Contact</Link>
          </nav>

      <button 
            onClick={handleAuthClick}
            className="flex items-center bg-blue-600 text-white px-4 py-2 rounded-full hover:bg-blue-700 transition"
          >
            {user ? (
              <>
                <FaUser className="mr-2" />
                <span>Dashboard</span>
              </>
            ) : (
              'Login'
            )}
          </button>
        </div>
      </header>

      {/* Hero Section */}
      <section id="home" className="bg-blue-50 py-20">
        <div className="container mx-auto px-6 flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 mb-10 md:mb-0">
            <h1 className="text-4xl md:text-5xl font-bold text-gray-800 mb-6">
              Quality Healthcare <br />
              <span className="text-blue-600">Made Simple</span>
            </h1>
            <p className="text-lg text-gray-600 mb-8">
              Our team of experienced doctors is dedicated to providing you with the best medical care.
            </p>
            <div className="flex space-x-4">
              <button className="bg-blue-600 text-white px-6 py-3 rounded-full hover:bg-blue-700 transition flex items-center">
                Book Appointment <FaArrowRight className="ml-2" />
              </button>
              <button className="border border-blue-600 text-blue-600 px-6 py-3 rounded-full hover:bg-blue-50 transition">
                Learn More
              </button>
            </div>
          </div>
          <div className="md:w-1/2">
            <Image 
              src="/images/hero1.webp" 
              alt="Doctor" 
              width={600} 
              height={500} 
              className="rounded-lg"
            />
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-white">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-800 mb-4">About Our Clinic</h2>
            <div className="w-20 h-1 bg-blue-600 mx-auto"></div>
          </div>
          
          <div className="flex flex-col md:flex-row items-center">
            <div className="md:w-1/2 mb-10 md:mb-0">
              <Image 
                src="/images/doctor2.jpg" 
                alt="Clinic" 
                width={600} 
                height={400} 
                className="rounded-lg shadow-lg"
              />
            </div>
            <div className="md:w-1/2 md:pl-12">
              <h3 className="text-2xl font-bold text-gray-800 mb-6">We Provide Best Medical Services</h3>
              <p className="text-gray-600 mb-6">
                Our clinic has been providing top-quality healthcare services for over 15 years. 
                We combine modern medical technology with compassionate care.
              </p>
              <ul className="space-y-4">
                <li className="flex items-start">
                  <div className="bg-blue-100 p-2 rounded-full mr-4">
                    <FaArrowRight className="text-blue-600" />
                  </div>
                  <span className="text-gray-700">Experienced and qualified doctors</span>
                </li>
                <li className="flex items-start">
                  <div className="bg-blue-100 p-2 rounded-full mr-4">
                    <FaArrowRight className="text-blue-600" />
                  </div>
                  <span className="text-gray-700">Modern medical equipment</span>
                </li>
                <li className="flex items-start">
                  <div className="bg-blue-100 p-2 rounded-full mr-4">
                    <FaArrowRight className="text-blue-600" />
                  </div>
                  <span className="text-gray-700">Emergency services 24/7</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Doctors Section */}
      <section id="doctors" className="py-20 bg-gray-50">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-800 mb-4">Our Specialist Doctors</h2>
            <div className="w-20 h-1 bg-blue-600 mx-auto"></div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[1, 2, 3].map((doctor) => (
              <div key={doctor} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition">
                <Image 
                  src={`/images/avatar1.jpeg`} 
                  alt={`Doctor ${doctor}`} 
                  width={400} 
                  height={400} 
                  className="w-full h-64 object-cover"
                />
                <div className="p-6">
                  <h3 className="text-xl font-bold text-gray-800 mb-2">Dr. {['Smith', 'Johnson', 'Williams'][doctor-1]}</h3>
                  <p className="text-blue-600 mb-4">{['Cardiologist', 'Neurologist', 'Pediatrician'][doctor-1]}</p>
                  <p className="text-gray-600 mb-4">
                    {[
                      'Specialized in heart diseases and treatment',
                      'Expert in brain and nervous system',
                      'Child specialist with 10 years experience'
                    ][doctor-1]}
                  </p>
                  <button className="text-blue-600 hover:text-blue-800 font-medium flex items-center">
                    View Profile <FaArrowRight className="ml-2" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Appointment Section */}
      <section id="appointment" className="py-20 bg-white">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-800 mb-4">Book an Appointment</h2>
            <div className="w-20 h-1 bg-blue-600 mx-auto"></div>
          </div>
          
          <div className="max-w-3xl mx-auto bg-blue-50 rounded-xl p-8 shadow-md">
            <form className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-gray-700 mb-2">Full Name</label>
                <input 
                  type="text" 
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Your Name"
                />
              </div>
              <div>
                <label className="block text-gray-700 mb-2">Email</label>
                <input 
                  type="email" 
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Your Email"
                />
              </div>
              <div>
                <label className="block text-gray-700 mb-2">Phone</label>
                <input 
                  type="tel" 
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Your Phone"
                />
              </div>
              <div>
                <label className="block text-gray-700 mb-2">Department</label>
                <select className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500">
                  <option>Select Department</option>
                  <option>Cardiology</option>
                  <option>Neurology</option>
                  <option>Pediatrics</option>
                  <option>Dermatology</option>
                </select>
              </div>
              <div>
                <label className="block text-gray-700 mb-2">Date</label>
                <input 
                  type="date" 
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-gray-700 mb-2">Time</label>
                <input 
                  type="time" 
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div className="md:col-span-2">
                <button 
                  type="submit"
                  className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition font-medium"
                >
                  Book Appointment
                </button>
              </div>
            </form>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-gray-50">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-800 mb-4">Contact Us</h2>
            <div className="w-20 h-1 bg-blue-600 mx-auto"></div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-lg shadow-md text-center">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <FaPhone className="text-blue-600 text-xl" />
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-2">Phone</h3>
              <p className="text-gray-600">+1 (123) 456-7890</p>
              <p className="text-gray-600">+1 (123) 456-7891</p>
            </div>
            
            <div className="bg-white p-8 rounded-lg shadow-md text-center">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <FaMapMarkerAlt className="text-blue-600 text-xl" />
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-2">Address</h3>
              <p className="text-gray-600">123 Medical Drive</p>
              <p className="text-gray-600">Health City, HC 12345</p>
            </div>
            
            <div className="bg-white p-8 rounded-lg shadow-md text-center">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <FaClock className="text-blue-600 text-xl" />
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-2">Opening Hours</h3>
              <p className="text-gray-600">Mon-Fri: 8:00 AM - 7:00 PM</p>
              <p className="text-gray-600">Sat-Sun: 9:00 AM - 5:00 PM</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-12">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-xl font-bold mb-4">HealthCare</h3>
              <p className="text-gray-400">
                Providing quality healthcare services with compassion and excellence.
              </p>
            </div>
            <div>
              <h4 className="font-bold mb-4">Quick Links</h4>
              <ul className="space-y-2">
                <li><Link href="#home" className="text-gray-400 hover:text-white">Home</Link></li>
                <li><Link href="#about" className="text-gray-400 hover:text-white">About</Link></li>
                <li><Link href="#doctors" className="text-gray-400 hover:text-white">Doctors</Link></li>
                <li><Link href="#appointment" className="text-gray-400 hover:text-white">Appointment</Link></li>
                <li><Link href="#contact" className="text-gray-400 hover:text-white">Contact</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Services</h4>
              <ul className="space-y-2">
                <li className="text-gray-400">Cardiology</li>
                <li className="text-gray-400">Neurology</li>
                <li className="text-gray-400">Pediatrics</li>
                <li className="text-gray-400">Dermatology</li>
                <li className="text-gray-400">Emergency</li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Newsletter</h4>
              <p className="text-gray-400 mb-4">Subscribe to our newsletter for updates.</p>
              <div className="flex">
                <input 
                  type="email" 
                  placeholder="Your Email" 
                  className="px-4 py-2 rounded-l-lg focus:outline-none text-gray-800 w-full"
                />
                <button className="bg-blue-600 px-4 py-2 rounded-r-lg hover:bg-blue-700">
                  Subscribe
                </button>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-700 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; {new Date().getFullYear()} HealthCare. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}